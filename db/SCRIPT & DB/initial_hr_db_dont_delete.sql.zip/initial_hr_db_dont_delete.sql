-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 15, 2023 at 09:30 AM
-- Server version: 10.6.12-MariaDB-0ubuntu0.22.04.1
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_HRM`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigned_roles`
--

CREATE TABLE `assigned_roles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assigned_roles`
--

INSERT INTO `assigned_roles` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `company_information`
--

CREATE TABLE `company_information` (
  `id` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `short_name` varchar(45) DEFAULT NULL,
  `contact_number` varchar(45) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `company_information_id` int(10) UNSIGNED DEFAULT NULL,
  `app_version` varchar(45) DEFAULT NULL,
  `users_id` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_exchange_emp`
--

CREATE TABLE `hrm_acc_exchange_emp` (
  `id` int(11) NOT NULL,
  `hrm_acc_head_title_id` int(10) UNSIGNED NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_headwise_emp_tag`
--

CREATE TABLE `hrm_acc_headwise_emp_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_head_title_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_headwise_emp_tag_category`
--

CREATE TABLE `hrm_acc_headwise_emp_tag_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_headwise_emp_tag_id` int(10) UNSIGNED NOT NULL,
  `hrm_category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_headwise_emp_tag_location`
--

CREATE TABLE `hrm_acc_headwise_emp_tag_location` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_headwise_emp_tag_id` int(10) UNSIGNED NOT NULL,
  `hrm_location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_headwise_emp_tag_salaryhead`
--

CREATE TABLE `hrm_acc_headwise_emp_tag_salaryhead` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_headwise_emp_tag_id` int(10) UNSIGNED NOT NULL,
  `hrm_salary_head_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_head_integration`
--

CREATE TABLE `hrm_acc_head_integration` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_head_title_id` int(10) UNSIGNED NOT NULL,
  `accounts_ledger_head_id` int(11) DEFAULT NULL,
  `accounts_ledger_head_name` varchar(100) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_head_title`
--

CREATE TABLE `hrm_acc_head_title` (
  `id` int(10) UNSIGNED NOT NULL,
  `head_name` varchar(100) DEFAULT NULL,
  `hrm_acc_head_title_id` int(10) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `hrm_acc_journal_type_id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL,
  `status` varchar(5) DEFAULT NULL,
  `isCompanyContribute` tinyint(4) DEFAULT NULL,
  `isSalaryAllow` tinyint(4) DEFAULT NULL,
  `isCasualWorker` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'DRorCR'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_journal_type`
--

CREATE TABLE `hrm_acc_journal_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `journal_type_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_processing_data_details`
--

CREATE TABLE `hrm_acc_processing_data_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_journal_type_id` int(11) DEFAULT NULL,
  `journal_type_name` varchar(45) DEFAULT NULL,
  `hrm_acc_headwise_emp_tag_id` int(11) DEFAULT NULL,
  `hrm_acc_head_title_id` int(11) DEFAULT NULL,
  `head_name` varchar(105) DEFAULT NULL,
  `hrm_salary_head_id` int(11) DEFAULT NULL,
  `hrm_location_id` int(11) DEFAULT NULL,
  `location_name` varchar(100) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `location_type` int(11) DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `hrm_month_id` int(11) DEFAULT NULL,
  `debit_amount` double DEFAULT NULL,
  `credit_amount` double DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `salary_apply_type` tinyint(4) DEFAULT NULL COMMENT '1=Salary\n2=friengBenifit',
  `hrm_category_id` int(11) DEFAULT NULL,
  `category_name` varchar(75) DEFAULT NULL,
  `isCompanyContribute` tinyint(4) DEFAULT NULL,
  `isSalaryAllow` tinyint(4) DEFAULT NULL,
  `isCasualWorker` tinyint(4) DEFAULT NULL,
  `transaction_number` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_acc_processing_data_details_costcenter`
--

CREATE TABLE `hrm_acc_processing_data_details_costcenter` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_acc_journal_type_id` int(11) DEFAULT NULL,
  `journal_type_name` varchar(45) DEFAULT NULL,
  `hrm_acc_headwise_emp_tag_id` int(11) DEFAULT NULL,
  `hrm_acc_head_title_id` int(11) DEFAULT NULL,
  `head_name` varchar(105) DEFAULT NULL,
  `hrm_salary_head_id` int(11) DEFAULT NULL,
  `hrm_location_id` int(11) DEFAULT NULL,
  `location_name` varchar(100) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `location_type` int(11) DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `hrm_month_id` int(11) DEFAULT NULL,
  `debit_amount` double DEFAULT NULL,
  `credit_amount` double DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `salary_apply_type` tinyint(4) DEFAULT NULL COMMENT '1=Salary\n2=friengBenifit',
  `hrm_category_id` int(11) DEFAULT NULL,
  `category_name` varchar(75) DEFAULT NULL,
  `isCompanyContribute` tinyint(4) DEFAULT NULL,
  `isSalaryAllow` tinyint(4) DEFAULT NULL,
  `isCasualWorker` tinyint(4) DEFAULT NULL,
  `transaction_number` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset`
--

CREATE TABLE `hrm_asset` (
  `id` int(11) NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `model` varchar(75) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `imgpath` varchar(95) DEFAULT NULL,
  `asset_type_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `depreciation_rate` double(8,3) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_assign_ledger`
--

CREATE TABLE `hrm_asset_assign_ledger` (
  `id` int(11) NOT NULL,
  `asset_assign_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` double DEFAULT NULL,
  `serial_no` varchar(65) DEFAULT NULL,
  `qty_stockout` double DEFAULT NULL,
  `is_valid` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_assign_master`
--

CREATE TABLE `hrm_asset_assign_master` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) DEFAULT NULL,
  `hrm_depertment_id` int(11) DEFAULT NULL,
  `hrm_asset_store_master_id` int(11) NOT NULL,
  `transaction_type` tinyint(4) DEFAULT NULL,
  `is_valid` tinyint(4) DEFAULT 1,
  `status` tinyint(4) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `assign_date` date DEFAULT NULL,
  `assign_no` varchar(45) DEFAULT NULL,
  `lock_status` tinyint(4) DEFAULT 1 COMMENT '1=for pending,2=for locked',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_brand`
--

CREATE TABLE `hrm_asset_brand` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(75) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_purchase_ledger`
--

CREATE TABLE `hrm_asset_purchase_ledger` (
  `id` int(11) NOT NULL,
  `asset_purchase_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` double DEFAULT NULL,
  `serial_no` varchar(65) DEFAULT NULL,
  `qty_stockin` double DEFAULT NULL,
  `is_valid` tinyint(4) DEFAULT 1,
  `depreciation_rate` double(8,3) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_purchase_master`
--

CREATE TABLE `hrm_asset_purchase_master` (
  `id` int(11) NOT NULL,
  `asset_store_master_id` int(11) NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `note` varchar(145) DEFAULT NULL,
  `purchase_no` varchar(65) DEFAULT NULL,
  `is_valid` tinyint(4) DEFAULT 1,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_return_master`
--

CREATE TABLE `hrm_asset_return_master` (
  `id` int(11) NOT NULL,
  `hrm_asset_assign_master_id` int(11) NOT NULL,
  `hrm_asset_store_master_id` int(11) NOT NULL,
  `note` varchar(145) DEFAULT NULL,
  `hrm_asset_return_type_id` int(11) NOT NULL,
  `is_valid` tinyint(4) DEFAULT 1,
  `return_date` date DEFAULT NULL,
  `return_no` varchar(45) DEFAULT NULL,
  `lock_status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL COMMENT '1=for pending,2=for locked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_return_type`
--

CREATE TABLE `hrm_asset_return_type` (
  `id` int(11) NOT NULL,
  `asset_return_type_name` varchar(75) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `return_status` tinyint(4) DEFAULT NULL COMMENT '1 for Reuse\n2 for Destroy',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='id 1 for Return 2 for Damage';

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_store_ledger`
--

CREATE TABLE `hrm_asset_store_ledger` (
  `id` int(11) NOT NULL,
  `asset_store_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` double DEFAULT NULL,
  `serial_no` varchar(75) DEFAULT NULL,
  `qty_stockin` double DEFAULT 0,
  `qty_stockout` double DEFAULT 0,
  `is_valid` tinyint(4) DEFAULT 1,
  `hrm_asset_store_ledger_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_store_master`
--

CREATE TABLE `hrm_asset_store_master` (
  `id` int(11) NOT NULL,
  `transaction_type` tinyint(4) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `is_valid` tinyint(4) DEFAULT 1,
  `store_no` varchar(45) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1 COMMENT '1=for pending,2=for locked',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_asset_type`
--

CREATE TABLE `hrm_asset_type` (
  `id` int(11) NOT NULL,
  `asset_type_name` varchar(75) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendance`
--

CREATE TABLE `hrm_attendance` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `punche_date` date DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `early_out_time` time DEFAULT NULL,
  `late_time` time DEFAULT NULL,
  `overtime_time` time DEFAULT NULL,
  `attendance_status` int(11) DEFAULT NULL COMMENT '1_for_absent\n2_for_present\n3_for_leave\n4_for_h_leave\n5_for_osd\n6_for_late\n7_for_Friday\n8_for_Holiday\n9_Without_Pay_Leave\n10_Half_Day_Leave_Without_Pay\n11_Holiday_Against_Leave',
  `comment` varchar(150) DEFAULT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `actual_overtime` time DEFAULT NULL,
  `hrm_location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendance_comment`
--

CREATE TABLE `hrm_attendance_comment` (
  `id` int(11) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `hrm_attendance_data_id` int(11) DEFAULT NULL,
  `entry_status` int(11) DEFAULT NULL COMMENT '1 for osd\n2 for attendance',
  `hrm_attendance_raw_data_id` int(11) DEFAULT NULL,
  `osd_time_status` int(11) DEFAULT 0 COMMENT '0 for time 00:00\n1 for take from attendance machine\n2 for manual time input'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendance_data`
--

CREATE TABLE `hrm_attendance_data` (
  `id` int(11) NOT NULL,
  `attandance_date` date DEFAULT NULL,
  `punch_date` datetime DEFAULT NULL,
  `punch_time` time DEFAULT NULL,
  `data_from` int(11) DEFAULT NULL COMMENT '1ForPunchData\n2ForManualPunch\n3ForHolidayProcess\n',
  `row_data_id` int(11) DEFAULT NULL COMMENT 'as_hrm_attendance_raw_data_id',
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `punch_status` varchar(45) DEFAULT NULL COMMENT '0_for_In\n1_For_Out'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendance_data_process_log`
--

CREATE TABLE `hrm_attendance_data_process_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '1 for Process\n0 for End',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendance_raw_data`
--

CREATE TABLE `hrm_attendance_raw_data` (
  `id` int(11) NOT NULL,
  `device_no` varchar(45) DEFAULT NULL,
  `employee_code` varchar(55) DEFAULT NULL,
  `punch_date` date DEFAULT NULL,
  `punch_time` time DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `serial_id` int(11) DEFAULT NULL,
  `is_new` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `data_from` int(11) DEFAULT NULL COMMENT '1_for_device\n2_for_manual',
  `valid` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendance_status`
--

CREATE TABLE `hrm_attendance_status` (
  `id` int(11) NOT NULL,
  `attendance_status` varchar(45) DEFAULT NULL,
  `alies` varchar(45) DEFAULT NULL,
  `effect_apply` int(11) DEFAULT NULL COMMENT 'example : 3 days late=1 days present minis then you just insert value here 3 if not apply then insert null value'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_bank`
--

CREATE TABLE `hrm_bank` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(145) DEFAULT NULL,
  `short_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_blood_group`
--

CREATE TABLE `hrm_blood_group` (
  `id` int(11) NOT NULL,
  `blood_group` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_blood_group`
--

INSERT INTO `hrm_blood_group` (`id`, `blood_group`) VALUES
(1, 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_bonus`
--

CREATE TABLE `hrm_bonus` (
  `id` int(11) NOT NULL,
  `bonus_name` varchar(145) DEFAULT NULL,
  `bonus_description` varchar(145) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_category`
--

CREATE TABLE `hrm_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(155) DEFAULT NULL,
  `category_description` varchar(150) DEFAULT NULL,
  `priority` smallint(5) UNSIGNED DEFAULT NULL,
  `ot_rate` double DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_change_employee_shift`
--

CREATE TABLE `hrm_change_employee_shift` (
  `id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `punch_date` date DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_custom_filter`
--

CREATE TABLE `hrm_custom_filter` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `table_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_custom_filter_details`
--

CREATE TABLE `hrm_custom_filter_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_custom_filter_master_id` int(10) UNSIGNED NOT NULL,
  `ref_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_custom_filter_master`
--

CREATE TABLE `hrm_custom_filter_master` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_name` varchar(45) DEFAULT NULL,
  `valid` tinyint(4) DEFAULT NULL,
  `hrm_custom_filter_id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_compensation`
--

CREATE TABLE `hrm_cv_compensation` (
  `id` int(11) NOT NULL,
  `compensation_name` varchar(75) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_drop_details`
--

CREATE TABLE `hrm_cv_drop_details` (
  `id` int(11) NOT NULL,
  `hrm_cv_drop_master_id` int(11) NOT NULL,
  `hrm_cv_job_requsition_details_id` int(11) NOT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `note` varchar(145) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_drop_master`
--

CREATE TABLE `hrm_cv_drop_master` (
  `id` int(11) NOT NULL,
  `applicant_name` varchar(75) DEFAULT NULL,
  `applicant_contact_no` varchar(45) DEFAULT NULL,
  `applicant_email` varchar(45) DEFAULT NULL,
  `present_address` varchar(100) DEFAULT NULL,
  `attachment` varchar(45) DEFAULT NULL,
  `hrm_cv_job_requsition_id` int(11) NOT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL COMMENT '1 for Pending\n2 for call for viva\n3 for futute use\n4 for finally reject\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_job_description`
--

CREATE TABLE `hrm_cv_job_description` (
  `id` int(11) NOT NULL,
  `hrm_cv_job_description_group_id` int(11) NOT NULL,
  `job_description` varchar(245) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `hrm_depertment_id` int(11) NOT NULL,
  `allow_points_calculation` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'if    0    then not applicable\nif    1     then calculation points\n '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_job_description_group`
--

CREATE TABLE `hrm_cv_job_description_group` (
  `id` int(11) NOT NULL,
  `job_description_group_name` varchar(85) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_job_requsition`
--

CREATE TABLE `hrm_cv_job_requsition` (
  `id` int(11) NOT NULL,
  `job_title` varchar(150) DEFAULT NULL,
  `job_context` varchar(350) DEFAULT NULL,
  `employment_status` varchar(85) DEFAULT NULL,
  `job_level` varchar(85) DEFAULT NULL,
  `work_place` varchar(85) DEFAULT NULL,
  `gender` varchar(85) DEFAULT NULL,
  `salary_range` varchar(85) DEFAULT NULL,
  `job_location` varchar(85) DEFAULT NULL,
  `lunch_facilities` varchar(85) DEFAULT NULL,
  `festival_bonus` varchar(15) DEFAULT NULL,
  `salary_review` varchar(55) DEFAULT NULL,
  `age_range` varchar(85) DEFAULT NULL,
  `vacancy` varchar(85) DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  `hrm_depertment_id` int(11) NOT NULL,
  `hrm_designation_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `approved_by_users_id` int(11) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '1 for Pending\n2 for Approve\n0 for Reject\n',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_job_requsition_compensation`
--

CREATE TABLE `hrm_cv_job_requsition_compensation` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_cv_compensation_id` int(11) NOT NULL,
  `hrm_cv_job_requsition_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_cv_job_requsition_details`
--

CREATE TABLE `hrm_cv_job_requsition_details` (
  `id` int(11) NOT NULL,
  `hrm_cv_job_description_id` int(11) NOT NULL,
  `point` double DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `hrm_cv_job_requsition_id` int(11) NOT NULL,
  `note` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_days_name`
--

CREATE TABLE `hrm_days_name` (
  `id` int(10) UNSIGNED NOT NULL,
  `days_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_days_name`
--

INSERT INTO `hrm_days_name` (`id`, `days_name`) VALUES
(1, 'Saturday'),
(2, 'Sunday'),
(3, 'Monday'),
(4, 'Tuesday'),
(5, 'Wednesday'),
(6, 'Thursday'),
(7, 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_default_head`
--

CREATE TABLE `hrm_default_head` (
  `id` int(11) NOT NULL,
  `head_name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `status` smallint(5) UNSIGNED DEFAULT 1 COMMENT '1 for default head\n2 for Provident Fund Confiquration\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_default_head`
--

INSERT INTO `hrm_default_head` (`id`, `head_name`, `description`, `status`) VALUES
(1, 'basic_salary', 'Basic Salary', 1),
(2, 'attendance_deduction', 'Attendance Deduction', 1),
(3, 'provident_fund', 'Provident Fund', 1),
(4, 'own_contribution', 'Own Contribution', 2),
(5, 'company_contribution', 'Company Contribution', 2);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_deleted_data_log`
--

CREATE TABLE `hrm_deleted_data_log` (
  `id` int(11) NOT NULL,
  `user_name` varchar(75) DEFAULT NULL,
  `delete_from` varchar(120) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `master_table_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_depertment`
--

CREATE TABLE `hrm_depertment` (
  `id` int(11) NOT NULL,
  `depertment_name` varchar(155) DEFAULT NULL,
  `depertment_description` varchar(150) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_designation`
--

CREATE TABLE `hrm_designation` (
  `id` int(11) NOT NULL,
  `designation_name` varchar(155) DEFAULT NULL,
  `alis` varchar(50) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_device_information`
--

CREATE TABLE `hrm_device_information` (
  `id` int(11) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  `support_device_details` text DEFAULT NULL,
  `short_description` varchar(45) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_device_information`
--

INSERT INTO `hrm_device_information` (`id`, `description`, `support_device_details`, `short_description`, `isActive`) VALUES
(1, 'ZkTech', 'ZK All Device', 'ZK Native Software', 1),
(2, 'ANVIZ', 'ANVIZ', 'ANVIZ SKD', 1),
(3, 'HUNDURE', 'HUNDURE', 'HUNDURE Native Software', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_education`
--

CREATE TABLE `hrm_education` (
  `id` int(11) NOT NULL,
  `education_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_education`
--

INSERT INTO `hrm_education` (`id`, `education_name`) VALUES
(1, 'Unknown '),
(2, 'Under Class 5'),
(3, 'PSC '),
(4, 'Ebtedayee (Madrasah) '),
(5, '5 Pass '),
(6, 'JSC '),
(7, 'JDC (Madrasah) '),
(8, '8 Pass'),
(9, 'SSC'),
(10, 'O Level'),
(11, 'Dakhil (Madrasah)'),
(12, 'SSC (Vocational) '),
(13, 'HSC '),
(14, 'A Level '),
(15, 'Alim (Madrasah) '),
(16, 'HSC (Vocational) '),
(17, 'Diploma in Engineering '),
(18, 'Diploma in Medical Technology '),
(19, 'Diploma in Nursing '),
(20, 'Diploma in Commerce '),
(21, 'Diploma in Business Studies '),
(22, 'Post Graduate Diploma (PGD) '),
(23, 'Diploma in Pathology '),
(24, 'Diploma (Vocational) '),
(25, 'Bachelor of Science (BSc) '),
(26, 'Bachelor of Arts (BA) '),
(27, 'Bachelor of Commerce (BCom) '),
(28, 'Bachelor of Commerce (Pass) '),
(29, 'Bachelor of Business Administration (BBA) '),
(30, 'Bachelor of Medicine and Bachelor of Surgery(MBBS) '),
(31, 'Bachelor of Dental Surgery (BDS) '),
(32, 'Bachelor of Architecture (B.Arch) '),
(33, 'Bachelor of Pharmacy (B.Pharm) '),
(34, 'Bachelor of Education (B.Ed) '),
(35, 'Bachelor of Physical Education (BPEd) '),
(36, 'Diploma in Hotel Management'),
(37, 'Bachelor in Engineering (BEngg) '),
(38, 'Bachelor of Law (LLB) '),
(39, 'Doctor of Veterinary Medicine (DVM) '),
(40, 'Bachelor of Social Science (BSS) '),
(41, 'Bachelor of Fine Arts (B.F.A) '),
(42, 'Bachelor of Business Studies (BBS) '),
(43, 'Bachelor of Computer Application (BCA) '),
(44, 'Fazil (Madrasah) '),
(45, 'Master of Science (MSc) '),
(46, 'Master of Arts (MA) '),
(47, 'Master of Commerce (MCom) '),
(48, 'Master of Business Administration (MBA) '),
(49, 'Master of Architecture (M.Arch) '),
(50, 'Master of Pharmacy (M.Pharm) '),
(51, 'Master of Education (M.Ed) '),
(52, 'Master of Law (LLM) '),
(53, 'Master of Social Science (MSS) '),
(54, 'Master of Fine Arts (M.F.A) '),
(55, 'Master of Philosophy (M.Phil) '),
(56, 'Master of Business Management (MBM) '),
(57, 'Master of Development Studies (MDS) '),
(58, 'Master of Business Studies (MBS) '),
(59, 'Masters in Computer Application (MCA) '),
(60, 'Executive Master of Business Administration (EMBA) '),
(61, 'Fellowship of the College of Physicians and Surgeons (FCPS) '),
(62, 'Kamil (Madrasah) '),
(63, 'Masters in Engineering (MEngg) '),
(64, 'Masters in Bank Management (MBM) '),
(65, 'Masters in Information Systems Security (MISS) '),
(66, 'Master of Information & Communication Technology (MICT) ');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_eligible_ot_employee`
--

CREATE TABLE `hrm_eligible_ot_employee` (
  `id` int(10) UNSIGNED NOT NULL,
  `apply_date` date DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `eligible_ot_hour` time DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `isActive` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_eligible_ot_pending`
--

CREATE TABLE `hrm_eligible_ot_pending` (
  `id` int(10) UNSIGNED NOT NULL,
  `apply_date` date DEFAULT NULL,
  `hrm_employee_id` varchar(45) DEFAULT NULL,
  `eligible_ot_hour` time DEFAULT NULL,
  `exceed_ot_hour` time DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee`
--

CREATE TABLE `hrm_employee` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(255) DEFAULT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `contact_number` varchar(25) DEFAULT NULL,
  `father_name` varchar(150) DEFAULT NULL,
  `mother_name` varchar(150) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `nid` varchar(45) DEFAULT NULL,
  `tin` varchar(45) DEFAULT NULL,
  `passport` varchar(45) DEFAULT NULL,
  `present_address` varchar(255) DEFAULT NULL,
  `permanent_address` varchar(255) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL COMMENT '1 for Male\n2 for Female',
  `hrm_blood_group_id` int(11) NOT NULL,
  `hrm_religion_id` int(11) NOT NULL,
  `hrm_marital_status_id` int(11) NOT NULL,
  `Images` varchar(255) DEFAULT NULL,
  `active_status` int(11) DEFAULT NULL COMMENT '1 for active\n0 for inactive',
  `hrm_education_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_activity`
--

CREATE TABLE `hrm_employee_activity` (
  `id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `activity_date` date DEFAULT NULL,
  `activity` int(11) DEFAULT NULL COMMENT '1 for IN\n2 for OUT\n3 for Both',
  `hrm_employee_activity_status_id` int(11) NOT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `old_hrm_employee_job_info_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_activity_status`
--

CREATE TABLE `hrm_employee_activity_status` (
  `id` int(11) NOT NULL,
  `description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_employee_activity_status`
--

INSERT INTO `hrm_employee_activity_status` (`id`, `description`) VALUES
(1, 'Join'),
(2, 'Transfer'),
(3, 'Promotion'),
(4, 'Increment');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_bonus`
--

CREATE TABLE `hrm_employee_bonus` (
  `id` int(11) NOT NULL,
  `hrm_bonus_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL,
  `amount_type` int(11) DEFAULT NULL COMMENT '1 for % 2 for Tk.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_bonus_cw`
--

CREATE TABLE `hrm_employee_bonus_cw` (
  `id` int(11) NOT NULL,
  `hrm_employee_bonus_master_id` int(11) NOT NULL,
  `rate` double DEFAULT NULL,
  `days` double DEFAULT NULL,
  `gross_salary` double DEFAULT NULL,
  `is_valid` tinyint(4) DEFAULT NULL,
  `zero_to_six_months` double DEFAULT NULL,
  `six_to_twelve_months` double DEFAULT NULL,
  `more_than_one_year` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_bonus_master`
--

CREATE TABLE `hrm_employee_bonus_master` (
  `id` int(11) NOT NULL,
  `declaration_date` date DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `based_on_month` date DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `amount_type` varchar(5) DEFAULT NULL,
  `is_valid` tinyint(4) DEFAULT 1,
  `status` tinyint(4) DEFAULT 1 COMMENT '1 for process\n2 for generate\n',
  `eligible_employee_type` varchar(45) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `hrm_bonus_id` int(11) NOT NULL,
  `payment_term` varchar(55) DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `note` varchar(100) DEFAULT NULL,
  `apply_for` tinyint(4) DEFAULT NULL,
  `basic_salary_of_gross` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL COMMENT '1 for General\n2 for Casual Worker\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_card_code`
--

CREATE TABLE `hrm_employee_card_code` (
  `id` int(11) NOT NULL,
  `card_code` varchar(100) DEFAULT NULL,
  `hrm_employee_id` int(11) DEFAULT NULL,
  `old_code` varchar(45) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_draft`
--

CREATE TABLE `hrm_employee_draft` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_name` varchar(255) DEFAULT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `contact_number` varchar(25) DEFAULT NULL,
  `father_name` varchar(150) DEFAULT NULL,
  `mother_name` varchar(150) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `nid` varchar(45) DEFAULT NULL,
  `tin` varchar(45) DEFAULT NULL,
  `passport` varchar(45) DEFAULT NULL,
  `present_address` varchar(255) DEFAULT NULL,
  `permanent_address` varchar(255) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `hrm_blood_group_id` int(11) DEFAULT NULL,
  `hrm_religion_id` int(11) DEFAULT NULL,
  `hrm_marital_status_id` int(11) DEFAULT NULL,
  `Images` varchar(255) DEFAULT NULL,
  `active_status` int(11) DEFAULT NULL,
  `hrm_education_id` int(11) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_file`
--

CREATE TABLE `hrm_employee_file` (
  `id` int(11) NOT NULL,
  `attached_date` date DEFAULT NULL,
  `file_title` varchar(145) DEFAULT NULL,
  `note` varchar(145) DEFAULT NULL,
  `images` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_file_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_holiday`
--

CREATE TABLE `hrm_employee_holiday` (
  `id` int(11) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `valid` int(11) NOT NULL,
  `hrm_holiday_id` int(11) NOT NULL,
  `apply_type` int(11) DEFAULT NULL COMMENT '1 for all employee\n2 for selected employee',
  `hrm_leave_years_id` int(11) NOT NULL,
  `process_status` int(11) DEFAULT NULL COMMENT '1 for new entry\n2 for process',
  `hrm_location_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_holiday_details`
--

CREATE TABLE `hrm_employee_holiday_details` (
  `id` int(11) NOT NULL,
  `hrm_employee_holiday_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_inactive`
--

CREATE TABLE `hrm_employee_inactive` (
  `id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `comment` varchar(145) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT 0 COMMENT '0 for processing\n1 for Inactive\n2 for Reactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_job_approval`
--

CREATE TABLE `hrm_employee_job_approval` (
  `id` int(11) NOT NULL,
  `action_type` tinyint(4) DEFAULT NULL COMMENT '1 for approved\n2 for reject',
  `comment` varchar(150) DEFAULT NULL,
  `forward` tinyint(4) DEFAULT NULL COMMENT '1 for forward\n2 for finally approved',
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `job_users_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_job_info`
--

CREATE TABLE `hrm_employee_job_info` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `employee_code` varchar(100) DEFAULT 'N/A',
  `hrm_depertment_id` int(11) NOT NULL,
  `hrm_designation_id` int(11) NOT NULL,
  `hrm_category_id` int(11) NOT NULL,
  `hrm_employment_status_id` int(11) NOT NULL,
  `hrm_manage_by_id` int(11) DEFAULT NULL COMMENT 'reporting boss',
  `employee_shift_status` int(11) NOT NULL COMMENT '0 for geraral shift\n1 for shifting',
  `overtime_status` int(11) NOT NULL COMMENT '0 for not applycable\n1 for applycable',
  `employee_activity` int(11) NOT NULL COMMENT '0 for deactive\n1 for active',
  `basic_salary` double DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `hrm_section_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hrm_plant_id` int(11) NOT NULL,
  `insurance` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_job_info_draft`
--

CREATE TABLE `hrm_employee_job_info_draft` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_employee_draft_id` int(11) DEFAULT NULL,
  `employee_code` varchar(100) DEFAULT 'N/A',
  `hrm_depertment_id` int(11) DEFAULT NULL,
  `hrm_designation_id` int(11) DEFAULT NULL,
  `hrm_category_id` int(11) DEFAULT NULL,
  `hrm_employment_status_id` int(11) DEFAULT NULL,
  `hrm_manage_by_id` int(11) DEFAULT NULL COMMENT 'reporting boss',
  `employee_shift_status` int(11) DEFAULT NULL COMMENT '0 for geraral shift\n1 for shifting',
  `overtime_status` int(11) DEFAULT NULL COMMENT '0 for not applycable\n1 for applycable',
  `employee_activity` int(11) DEFAULT NULL COMMENT '0 for deactive\\n1 for active',
  `basic_salary` double DEFAULT NULL,
  `hrm_location_id` int(11) DEFAULT NULL,
  `hrm_section_id` int(11) DEFAULT NULL,
  `hrm_plant_id` int(11) DEFAULT NULL,
  `insurance` int(11) DEFAULT 0,
  `probation_period` tinyint(4) DEFAULT 0,
  `working_shift_id` int(11) DEFAULT NULL,
  `salary_grade_id` int(11) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `card_code` varchar(100) DEFAULT NULL,
  `old_code` varchar(100) DEFAULT NULL,
  `device_id` varchar(100) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_joining`
--

CREATE TABLE `hrm_employee_joining` (
  `id` int(11) NOT NULL,
  `joining_date` date DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_leave_type`
--

CREATE TABLE `hrm_employee_leave_type` (
  `id` int(11) NOT NULL,
  `leave_type` varchar(45) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `leave_status` int(11) DEFAULT NULL COMMENT '1 for Company Policy\n2 for Holiday Against Leave'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_leave_year`
--

CREATE TABLE `hrm_employee_leave_year` (
  `id` int(11) NOT NULL,
  `hrm_leave_years_id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `with_pay_leave` double DEFAULT NULL,
  `without_pay_leave` double DEFAULT NULL,
  `encashment_leave` double DEFAULT NULL,
  `extra_leave` double DEFAULT NULL,
  `approve_leave` double DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='	';

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_long_service`
--

CREATE TABLE `hrm_employee_long_service` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `duration` double DEFAULT NULL,
  `service_completed_date` date DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `comment` varchar(145) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_probation`
--

CREATE TABLE `hrm_employee_probation` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_probation_period_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `note` varchar(105) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_resignation`
--

CREATE TABLE `hrm_employee_resignation` (
  `id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `apply_date` date DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `resingnation_status` int(11) DEFAULT NULL COMMENT '1 for new entry\n2 for approved\n3 for rejected\n4 pending for approved\n5 for Rejoin',
  `users_id` int(11) NOT NULL,
  `comment` varchar(160) DEFAULT NULL,
  `approve_comment` varchar(160) DEFAULT NULL,
  `resign_status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_salary`
--

CREATE TABLE `hrm_employee_salary` (
  `id` int(11) NOT NULL,
  `hrm_salary_grade_master_id` int(11) NOT NULL,
  `salary_amount` double DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `payment_mode` int(11) DEFAULT NULL COMMENT '1 for cash\n2 for bank',
  `account_no` varchar(45) DEFAULT NULL,
  `by_bank_percent` int(11) NOT NULL DEFAULT 0,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `hrm_bank_id` int(11) DEFAULT NULL,
  `accounts_code` varchar(45) DEFAULT NULL,
  `payment_mode_fb` int(11) DEFAULT 1 COMMENT '1 for cash\n2 for bank',
  `account_no_fb` varchar(45) DEFAULT NULL,
  `hrm_bank_id_fb` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_salary_details`
--

CREATE TABLE `hrm_employee_salary_details` (
  `id` int(11) NOT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL,
  `amount_type` int(11) DEFAULT NULL COMMENT '1 for %\n2 for tk',
  `actual_amount` double DEFAULT NULL,
  `hrm_employee_salary_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_shift`
--

CREATE TABLE `hrm_employee_shift` (
  `id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `comment` varchar(90) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_shift_auto`
--

CREATE TABLE `hrm_employee_shift_auto` (
  `id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `comment` varchar(90) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_task`
--

CREATE TABLE `hrm_employee_task` (
  `id` int(10) UNSIGNED NOT NULL,
  `task_name` text DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '1=Pending\n2=Pushed',
  `hrm_employee_task_type_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_task_assign`
--

CREATE TABLE `hrm_employee_task_assign` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_employee_task_id` int(10) UNSIGNED NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `priority` varchar(6) DEFAULT NULL COMMENT '1=High\n2=Medium\n3=Low',
  `assign_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `final_complete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_task_complete`
--

CREATE TABLE `hrm_employee_task_complete` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_employee_task_assign_id` int(10) UNSIGNED NOT NULL,
  `comments` varchar(150) DEFAULT NULL,
  `complete_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employee_task_type`
--

CREATE TABLE `hrm_employee_task_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `task_type_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employment_status`
--

CREATE TABLE `hrm_employment_status` (
  `id` int(11) NOT NULL,
  `employment_status` varchar(150) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '1 for General\n2 for Casual'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_employment_status`
--

INSERT INTO `hrm_employment_status` (`id`, `employment_status`, `status`) VALUES
(1, 'Probation', 1),
(2, 'Permanent', 1),
(3, 'Casual', 2),
(4, 'Contractual', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_favourite_link`
--

CREATE TABLE `hrm_favourite_link` (
  `id` int(11) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `link_address` varchar(170) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_file_type`
--

CREATE TABLE `hrm_file_type` (
  `id` int(11) NOT NULL,
  `file_type_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_fringe_benefits_config`
--

CREATE TABLE `hrm_fringe_benefits_config` (
  `id` int(11) NOT NULL,
  `hrm_designation_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT 1,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_fringe_benefits_config_details`
--

CREATE TABLE `hrm_fringe_benefits_config_details` (
  `id` int(11) NOT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `hrm_fringe_benefits_config_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL,
  `amount_type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_holiday`
--

CREATE TABLE `hrm_holiday` (
  `id` int(11) NOT NULL,
  `holiday_name` varchar(150) DEFAULT NULL,
  `holiday_description` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_holidayconvert_to_working`
--

CREATE TABLE `hrm_holidayconvert_to_working` (
  `id` int(11) NOT NULL,
  `action_date` date DEFAULT NULL,
  `purpose` varchar(145) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '1 for Make Holiday to Working Day\n2 for Make Working Day to Holiday',
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `valid` int(11) DEFAULT 1,
  `hrm_location_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_holiday_against_leave`
--

CREATE TABLE `hrm_holiday_against_leave` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `holiday_date` date DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_holiday_configure`
--

CREATE TABLE `hrm_holiday_configure` (
  `id` int(11) NOT NULL,
  `hrm_days_name_id` int(10) UNSIGNED NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_assesment_date`
--

CREATE TABLE `hrm_kpi_assesment_date` (
  `id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` varchar(45) DEFAULT NULL,
  `hrm_kpi_assesment_year_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_assesment_year`
--

CREATE TABLE `hrm_kpi_assesment_year` (
  `id` int(11) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_deduction_mark`
--

CREATE TABLE `hrm_kpi_deduction_mark` (
  `id` int(11) NOT NULL,
  `hrm_kpi_assesment_date_id` int(11) NOT NULL,
  `hrm_file_type_id` int(11) NOT NULL,
  `point` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_dept_head_assign_details`
--

CREATE TABLE `hrm_kpi_dept_head_assign_details` (
  `id` int(11) NOT NULL,
  `hrm_kpi_dept_head_assign_master_id` int(11) NOT NULL,
  `hrm_depertment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_dept_head_assign_master`
--

CREATE TABLE `hrm_kpi_dept_head_assign_master` (
  `id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `hrm_kpi_assesment_date_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT 1,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_dynamic_table`
--

CREATE TABLE `hrm_kpi_dynamic_table` (
  `id` int(10) UNSIGNED NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `table_field_name` varchar(85) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_kpi_dynamic_table`
--

INSERT INTO `hrm_kpi_dynamic_table` (`id`, `table_name`, `display_name`, `table_field_name`) VALUES
(1, 'N/A', 'N/A', NULL),
(2, 'hrm_category', 'Employee Category', NULL),
(3, 'hrm_designation', 'Designation', NULL),
(4, 'hrm_depertment', 'Department', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_employee_details`
--

CREATE TABLE `hrm_kpi_employee_details` (
  `id` int(11) NOT NULL,
  `hrm_kpi_employee_master_id` int(11) NOT NULL,
  `hrm_kpi_task_details_id` int(11) NOT NULL,
  `hrm_kpi_marks_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_employee_final_summary`
--

CREATE TABLE `hrm_kpi_employee_final_summary` (
  `id` int(11) NOT NULL,
  `hrm_kpi_employee_master_id` int(11) NOT NULL,
  `last_promotion_date` date DEFAULT NULL,
  `total_point` double DEFAULT NULL,
  `deduct_point` double DEFAULT NULL,
  `increment_amount` double DEFAULT NULL,
  `increment_amount_type` varchar(10) DEFAULT NULL,
  `promotion_status` varchar(45) DEFAULT NULL,
  `hrm_kpi_increment_range_id` int(11) DEFAULT NULL,
  `hrm_kpi_promotion_range_id` int(11) DEFAULT NULL,
  `note` varchar(245) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_employee_mark_deduct`
--

CREATE TABLE `hrm_kpi_employee_mark_deduct` (
  `id` int(11) NOT NULL,
  `hrm_kpi_employee_master_id` int(11) NOT NULL,
  `activity_date` date DEFAULT NULL,
  `hrm_file_type_id` int(11) NOT NULL,
  `point` double DEFAULT NULL,
  `valid` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_employee_master`
--

CREATE TABLE `hrm_kpi_employee_master` (
  `id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `hrm_kpi_assesment_date_id` int(11) NOT NULL,
  `comments` varchar(250) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `valid` int(11) NOT NULL DEFAULT 1,
  `status` int(11) DEFAULT 1 COMMENT '1 for Process\n2 for submit\n',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_increment_range`
--

CREATE TABLE `hrm_kpi_increment_range` (
  `id` int(11) NOT NULL,
  `number_from` double DEFAULT NULL,
  `number_to` double DEFAULT NULL,
  `increment_amount` double DEFAULT NULL,
  `increment_amount_type` int(11) DEFAULT NULL COMMENT '1 for %\n2 for Tk.',
  `hrm_kpi_assesment_date_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT 1,
  `entry_status` int(11) DEFAULT NULL COMMENT '1 for Increment\n2 for Promotion\n',
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_marks`
--

CREATE TABLE `hrm_kpi_marks` (
  `id` int(11) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `point` double DEFAULT NULL,
  `valid` int(11) NOT NULL DEFAULT 1,
  `users_id` int(11) NOT NULL,
  `hrm_kpi_set_config_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_set_config`
--

CREATE TABLE `hrm_kpi_set_config` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `hrm_kpi_assesment_date_id` int(11) NOT NULL,
  `tag_with_department` int(10) UNSIGNED DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `isActive` tinyint(4) DEFAULT 1,
  `is_confirmed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_set_config_department`
--

CREATE TABLE `hrm_kpi_set_config_department` (
  `id` int(11) NOT NULL,
  `hrm_depertment_id` int(11) NOT NULL,
  `hrm_kpi_set_config_id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_set_config_dept_with`
--

CREATE TABLE `hrm_kpi_set_config_dept_with` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_kpi_set_config_department_id` int(11) NOT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_task`
--

CREATE TABLE `hrm_kpi_task` (
  `id` int(11) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `hrm_kpi_task_type_id` int(11) NOT NULL,
  `valid` int(11) NOT NULL DEFAULT 1,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_task_department`
--

CREATE TABLE `hrm_kpi_task_department` (
  `id` int(11) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `valid` int(11) NOT NULL DEFAULT 1,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_task_department_details`
--

CREATE TABLE `hrm_kpi_task_department_details` (
  `id` int(11) NOT NULL,
  `hrm_depertment_id` int(11) NOT NULL,
  `hrm_kpi_task_department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_task_details`
--

CREATE TABLE `hrm_kpi_task_details` (
  `id` int(11) NOT NULL,
  `hrm_kpi_task_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT 1,
  `hrm_kpi_set_config_id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hrm_kpi_task_department_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_kpi_task_type`
--

CREATE TABLE `hrm_kpi_task_type` (
  `id` int(11) NOT NULL,
  `task_type_name` varchar(65) DEFAULT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_last_promotion`
--

CREATE TABLE `hrm_last_promotion` (
  `id` int(11) NOT NULL,
  `promotion_date` date DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_leave_application`
--

CREATE TABLE `hrm_leave_application` (
  `id` int(11) NOT NULL,
  `applied` date DEFAULT NULL,
  `hrm_employee_leave_type_id` int(11) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL COMMENT '1 for half day\n2 for full day\n3 for Quater Day',
  `payment_mode` int(11) DEFAULT NULL COMMENT '1 with pay\n2 for without pay',
  `valid` int(11) DEFAULT NULL,
  `hrm_leave_years_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_leave_approve`
--

CREATE TABLE `hrm_leave_approve` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) DEFAULT NULL,
  `action_type` int(11) DEFAULT NULL COMMENT '1 for approved\n2 for reject',
  `comment` varchar(150) DEFAULT NULL,
  `forward` int(11) DEFAULT NULL COMMENT '1 for forward\n2 for finally approved',
  `users_id` int(11) NOT NULL,
  `hrm_leave_application_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_leave_ledger`
--

CREATE TABLE `hrm_leave_ledger` (
  `id` int(11) NOT NULL,
  `hrm_leave_approve_id` int(11) DEFAULT NULL,
  `available_leave` double DEFAULT 0,
  `used_leave` double DEFAULT 0,
  `valid` int(11) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL COMMENT '1 for Opening\n2 for Leave',
  `hrm_leave_years_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_employee_leave_type_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_leave_type_year`
--

CREATE TABLE `hrm_leave_type_year` (
  `id` int(11) NOT NULL,
  `hrm_leave_years_id` int(11) NOT NULL,
  `hrm_employee_leave_type_id` int(11) NOT NULL,
  `leave_days` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_leave_years`
--

CREATE TABLE `hrm_leave_years` (
  `id` int(11) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `leave_year` varchar(150) DEFAULT NULL,
  `active_status` int(11) DEFAULT NULL COMMENT '1 for create new\n2 for active\n3 for cloase\n0 for deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_loan_application`
--

CREATE TABLE `hrm_loan_application` (
  `id` int(11) NOT NULL,
  `apply_date` date DEFAULT NULL,
  `opening_loan_amount` double DEFAULT 0,
  `paid_amount` double DEFAULT 0,
  `remaining_amount` double DEFAULT 0,
  `hrm_employee_id` int(11) NOT NULL,
  `no_of_installment` int(11) NOT NULL,
  `installment_size` double DEFAULT NULL,
  `approved_status` int(11) NOT NULL COMMENT '1 for Application\n2 for Approved\n0 for Reject',
  `installment_start_date` date DEFAULT NULL,
  `interest_rate` double DEFAULT 0,
  `hrm_loan_type_id` int(11) NOT NULL,
  `instalment_type` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_loan_ledger`
--

CREATE TABLE `hrm_loan_ledger` (
  `id` int(11) NOT NULL,
  `hrm_loan_application_id` int(11) NOT NULL,
  `debit` double DEFAULT 0,
  `credit` double DEFAULT NULL,
  `hrm_month_id` int(11) NOT NULL,
  `year_id` int(11) DEFAULT NULL,
  `valid` int(11) NOT NULL,
  `narration` varchar(150) DEFAULT NULL,
  `interest_amount` double DEFAULT 0,
  `users_id` int(11) NOT NULL,
  `entry_status` int(11) DEFAULT 1 COMMENT '1 for Auto\n2 for Manual'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_loan_payregister_details`
--

CREATE TABLE `hrm_loan_payregister_details` (
  `id` int(11) NOT NULL,
  `hrm_loan_application_id` int(11) NOT NULL,
  `pay_register_details_id` int(11) NOT NULL,
  `hrm_loan_ledger_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_loan_type`
--

CREATE TABLE `hrm_loan_type` (
  `id` int(11) NOT NULL,
  `loan_type` text DEFAULT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_location`
--

CREATE TABLE `hrm_location` (
  `id` int(11) NOT NULL,
  `location_name` varchar(150) DEFAULT NULL,
  `location_description` varchar(255) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `location_type` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `hrm_device_information_id` int(11) DEFAULT 0,
  `overtime_eligibility` int(11) DEFAULT 0,
  `ot_eligibility_include_exclude` int(11) DEFAULT 1 COMMENT '1=Include\n2=Exclude\n',
  `ot_rules` tinyint(4) DEFAULT 1 COMMENT '1=General\n2=DefinedEmployee\n',
  `is_wh_location_wise` tinyint(4) DEFAULT 1,
  `shifting_rules` tinyint(4) DEFAULT 1 COMMENT '1=Manual\n2=Auto\n3=FixedHours',
  `is_auto_ot_adjust` tinyint(4) DEFAULT 1 COMMENT '1=No\n2=Yes\n',
  `is_early_out` tinyint(4) DEFAULT 0 COMMENT '1=Yes \n0=No',
  `is_employee_joining_approval` tinyint(4) DEFAULT 0 COMMENT '0=No\n1=Yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_location`
--

INSERT INTO `hrm_location` (`id`, `location_name`, `location_description`, `valid`, `users_id`, `location_type`, `hrm_device_information_id`, `overtime_eligibility`, `ot_eligibility_include_exclude`, `ot_rules`, `is_wh_location_wise`, `shifting_rules`, `is_auto_ot_adjust`, `is_early_out`, `is_employee_joining_approval`, `created_at`, `updated_at`) VALUES
(1, 'Head Office', 'Head Office', 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, '2023-11-15 06:09:48', '2023-11-15 06:09:48');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_location_interval`
--

CREATE TABLE `hrm_location_interval` (
  `id` int(11) NOT NULL,
  `interval_time` int(11) DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `grace_minute` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_manual_ot`
--

CREATE TABLE `hrm_manual_ot` (
  `id` int(11) NOT NULL,
  `punch_date` date DEFAULT NULL,
  `overtime` time DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_marital_status`
--

CREATE TABLE `hrm_marital_status` (
  `id` int(11) NOT NULL,
  `marital_status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_marital_status`
--

INSERT INTO `hrm_marital_status` (`id`, `marital_status`) VALUES
(1, 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_month`
--

CREATE TABLE `hrm_month` (
  `id` int(11) NOT NULL,
  `month_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_month`
--

INSERT INTO `hrm_month` (`id`, `month_name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_mynote`
--

CREATE TABLE `hrm_mynote` (
  `id` int(11) NOT NULL,
  `my_note` varchar(150) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_organogram`
--

CREATE TABLE `hrm_organogram` (
  `id` int(11) NOT NULL,
  `hrm_designation_id` int(11) NOT NULL COMMENT 'child designation id \n',
  `hrm_parent_id` int(11) DEFAULT NULL COMMENT 'parent designation id',
  `hrm_depertment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_ot_process_details`
--

CREATE TABLE `hrm_ot_process_details` (
  `id` int(11) NOT NULL,
  `hrm_ot_process_master_id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `actual_overtime` time DEFAULT NULL,
  `net_overtime` double DEFAULT 0,
  `rate` double DEFAULT 0,
  `basic_salary` double DEFAULT 0,
  `actual_ot_rate` double DEFAULT 0,
  `gross_salary` double DEFAULT 0,
  `addition_amt` double DEFAULT 0,
  `deduction_amt` double DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_ot_process_master`
--

CREATE TABLE `hrm_ot_process_master` (
  `id` int(11) NOT NULL,
  `year_id` int(11) DEFAULT NULL,
  `hrm_month_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `process_status` int(11) DEFAULT NULL COMMENT '1 for process\n2 for generate\n0 for delete\n',
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_ot_time`
--

CREATE TABLE `hrm_ot_time` (
  `id` int(11) NOT NULL,
  `attandance_date` date DEFAULT NULL,
  `punche_date_time` datetime DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_plant`
--

CREATE TABLE `hrm_plant` (
  `id` int(11) NOT NULL,
  `plant_name` varchar(100) DEFAULT NULL,
  `hrm_location_id` int(11) DEFAULT NULL,
  `valid` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_plant`
--

INSERT INTO `hrm_plant` (`id`, `plant_name`, `hrm_location_id`, `valid`) VALUES
(1, 'N/A', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_plantwise_employee`
--

CREATE TABLE `hrm_plantwise_employee` (
  `id` int(11) NOT NULL,
  `hrm_plant_id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `hrm_plant_with_section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_plant_details`
--

CREATE TABLE `hrm_plant_details` (
  `id` int(11) NOT NULL,
  `hrm_plant_id` int(11) NOT NULL,
  `hrm_month_id` int(11) NOT NULL,
  `year_id` int(11) NOT NULL,
  `working_days` double DEFAULT NULL,
  `max_rate` double DEFAULT NULL,
  `minimum_rate` double DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `hrm_plant_with_section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_plant_with_section`
--

CREATE TABLE `hrm_plant_with_section` (
  `id` int(11) NOT NULL,
  `hrm_plant_id` int(11) NOT NULL,
  `hrm_section_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `valid` smallint(5) UNSIGNED DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_probation_period`
--

CREATE TABLE `hrm_probation_period` (
  `id` int(11) NOT NULL,
  `period` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_probation_period`
--

INSERT INTO `hrm_probation_period` (`id`, `period`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20),
(21, 21),
(22, 22),
(23, 23),
(24, 24);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_redflag`
--

CREATE TABLE `hrm_redflag` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_religion`
--

CREATE TABLE `hrm_religion` (
  `id` int(11) NOT NULL,
  `religion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_religion`
--

INSERT INTO `hrm_religion` (`id`, `religion`) VALUES
(1, 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_deduction`
--

CREATE TABLE `hrm_salary_deduction` (
  `id` int(10) UNSIGNED NOT NULL,
  `month_from` date DEFAULT NULL,
  `month_to` date DEFAULT NULL,
  `purpose` varchar(150) DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_extra_feature`
--

CREATE TABLE `hrm_salary_extra_feature` (
  `id` int(11) NOT NULL,
  `month_from` date DEFAULT NULL,
  `month_to` date DEFAULT NULL,
  `purpose` varchar(100) DEFAULT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `generate_type` int(11) DEFAULT 1 COMMENT '0 for Delete\n1 for Create\n2 for Generate\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_extra_feature_details`
--

CREATE TABLE `hrm_salary_extra_feature_details` (
  `id` int(11) NOT NULL,
  `hrm_salary_extra_feature_id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_generate_master`
--

CREATE TABLE `hrm_salary_generate_master` (
  `id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `hrm_month_id` int(11) NOT NULL,
  `year_id` int(11) DEFAULT NULL,
  `declaration_date` date DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `hrm_salary_slap_id` int(11) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '1 for Salary Process\n2 for FB Process\n3 for CW Process\n\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_grade`
--

CREATE TABLE `hrm_salary_grade` (
  `id` int(11) NOT NULL,
  `grade_name` varchar(55) DEFAULT NULL,
  `valid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_salary_grade`
--

INSERT INTO `hrm_salary_grade` (`id`, `grade_name`, `valid`) VALUES
(1, 'Grade A', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_grade_details`
--

CREATE TABLE `hrm_salary_grade_details` (
  `id` int(11) NOT NULL,
  `hrm_salary_grade_master_id` int(11) NOT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL,
  `amount_type` int(11) DEFAULT NULL COMMENT '1 for %\n2 for tk',
  `actual_amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_salary_grade_details`
--

INSERT INTO `hrm_salary_grade_details` (`id`, `hrm_salary_grade_master_id`, `hrm_salary_head_id`, `amount`, `amount_type`, `actual_amount`) VALUES
(1, 1, 1, 50, 1, NULL),
(2, 1, 7, 25, 1, NULL),
(3, 1, 8, 5, 1, NULL),
(4, 1, 10, 5, 1, NULL),
(5, 1, 11, 15, 1, NULL),
(6, 1, 12, 0, 2, NULL),
(7, 1, 14, 0, 2, NULL),
(8, 1, 15, 0, 2, NULL),
(9, 1, 16, 0, 2, NULL),
(10, 1, 18, 0, 2, NULL),
(11, 1, 2, 0, 2, NULL),
(12, 1, 3, 0, 2, NULL),
(13, 1, 4, 0, 1, NULL),
(14, 1, 5, 0, 2, NULL),
(15, 1, 6, 0, 2, NULL),
(16, 1, 9, 0, 2, NULL),
(17, 1, 13, 0, 2, NULL),
(18, 1, 17, 0, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_grade_master`
--

CREATE TABLE `hrm_salary_grade_master` (
  `id` int(11) NOT NULL,
  `hrm_salary_grade_id` int(11) NOT NULL,
  `salary_type` int(11) DEFAULT NULL COMMENT '1 for basic\n2 for gross',
  `salary_size` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_salary_grade_master`
--

INSERT INTO `hrm_salary_grade_master` (`id`, `hrm_salary_grade_id`, `salary_type`, `salary_size`) VALUES
(1, 1, 1, '100-999999999');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_head`
--

CREATE TABLE `hrm_salary_head` (
  `id` int(11) NOT NULL,
  `hrm_salary_head_group_id` int(11) NOT NULL,
  `salary_head` varchar(45) DEFAULT NULL,
  `active_status` int(11) DEFAULT NULL COMMENT '1 for active\n2 for deactive\n',
  `users_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT NULL COMMENT '1 for delete\n2 for dont delete',
  `apply_for` int(11) NOT NULL COMMENT '1 for Salary Sheet\n2 for Other Special Benefit'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_salary_head`
--

INSERT INTO `hrm_salary_head` (`id`, `hrm_salary_head_group_id`, `salary_head`, `active_status`, `users_id`, `is_delete`, `apply_for`) VALUES
(1, 1, 'Basic', 1, 1, 1, 1),
(2, 2, 'Loan', 1, 1, 2, 1),
(3, 3, 'Attendance', 1, 1, 2, 1),
(4, 4, 'PF', 1, 1, 1, 1),
(5, 5, 'Others Deduction', 1, 1, 1, 1),
(6, 6, 'AIT', 1, 1, 1, 1),
(7, 7, 'House Rent', 1, 1, 1, 1),
(8, 8, 'Medical', 1, 1, 1, 1),
(9, 9, 'Stamp', 1, 1, 1, 1),
(10, 10, 'Transportation', 1, 1, 1, 1),
(11, 11, 'Other Allowances', 1, 1, 1, 1),
(12, 12, 'Fixed Allowance', 1, 1, 1, 2),
(13, 13, 'Car Allowance Deduction', 1, 1, 1, 2),
(14, 14, 'Car Allowance', 1, 1, 1, 2),
(15, 15, 'House Rent Allowance', 1, 1, 1, 2),
(16, 16, 'Out Of pocket', 1, 1, 1, 2),
(17, 17, 'Out of Pocket Deduction', 1, 1, 1, 2),
(18, 18, 'Other Addition', 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_head_group`
--

CREATE TABLE `hrm_salary_head_group` (
  `id` int(11) NOT NULL,
  `group_name` varchar(45) DEFAULT NULL,
  `generate_type` int(11) DEFAULT NULL COMMENT '1 for addition\n2 for deduction',
  `group_status` int(11) DEFAULT NULL COMMENT '1 THEN ''Salary''\n2 THEN ''Bonus''\n3 THEN ''Loan''\n4 THEN ''PF''\n5 THEN ''Additional Salary''\n',
  `is_delete` smallint(5) UNSIGNED DEFAULT 1 COMMENT '1 for Yes\n2 for No\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_salary_head_group`
--

INSERT INTO `hrm_salary_head_group` (`id`, `group_name`, `generate_type`, `group_status`, `is_delete`) VALUES
(1, 'Basic', 1, 1, 1),
(2, 'Loan/Advance', 2, 3, 1),
(3, 'Attendance Deduction', 2, 1, 1),
(4, 'PF', 2, 4, 1),
(5, 'Others Deduction', 2, 1, 1),
(6, 'AIT', 2, 1, 1),
(7, 'House Rent', 1, 1, 1),
(8, 'Medical', 1, 1, 1),
(9, 'Stamp', 2, 1, 1),
(10, 'Transportation', 1, 1, 1),
(11, 'Other Allowances', 1, 1, 1),
(12, 'Fixed Allowance', 1, 5, 1),
(13, 'Car Allowance Deduction', 2, 6, 1),
(14, 'Car Allowance ', 1, 5, 1),
(15, 'House Rent Allowance', 1, 5, 1),
(16, 'Out Of pocket', 1, 5, 1),
(17, 'Out of Pocket Deduction', 2, 6, 1),
(18, 'Others Addition', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_increment`
--

CREATE TABLE `hrm_salary_increment` (
  `id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `effective_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '1 for process\n2 for applied\n',
  `apply_for` tinyint(4) DEFAULT 1 COMMENT '1 for Increment\n2 for Promotion\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_increment_details`
--

CREATE TABLE `hrm_salary_increment_details` (
  `id` int(11) NOT NULL,
  `hrm_salary_increment_id` int(11) NOT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `salary_amount` double DEFAULT NULL,
  `increase_amount` double DEFAULT NULL,
  `amount_type` int(11) DEFAULT NULL COMMENT '1 for %\n2 for tk.\n',
  `new_salary_amount` double DEFAULT NULL,
  `hrm_designation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_slap`
--

CREATE TABLE `hrm_salary_slap` (
  `id` int(11) NOT NULL,
  `slap_name` varchar(100) DEFAULT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `hrm_month_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_section`
--

CREATE TABLE `hrm_section` (
  `id` int(11) NOT NULL,
  `section_name` varchar(155) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_set_default_head`
--

CREATE TABLE `hrm_set_default_head` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_default_head_id` int(11) NOT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_set_default_head`
--

INSERT INTO `hrm_set_default_head` (`id`, `hrm_default_head_id`, `hrm_salary_head_id`, `users_id`) VALUES
(1, 1, 1, 1),
(2, 2, 3, 1),
(3, 3, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_set_pf_confiq`
--

CREATE TABLE `hrm_set_pf_confiq` (
  `id` int(11) NOT NULL,
  `hrm_default_head_id_own` int(11) NOT NULL,
  `amount_own` double DEFAULT NULL,
  `hrm_default_head_id_company` int(11) NOT NULL,
  `amount_company` double DEFAULT NULL,
  `amount_type` varchar(10) DEFAULT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `calculation_on` tinyint(4) DEFAULT NULL COMMENT '1=Basic\n2=Gross ',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrm_set_pf_confiq`
--

INSERT INTO `hrm_set_pf_confiq` (`id`, `hrm_default_head_id_own`, `amount_own`, `hrm_default_head_id_company`, `amount_company`, `amount_type`, `date_from`, `date_to`, `users_id`, `calculation_on`, `created_at`, `updated_at`) VALUES
(1, 4, 0, 5, 0, '%', '2020-01-01', NULL, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `hrm_shift`
--

CREATE TABLE `hrm_shift` (
  `id` int(11) NOT NULL COMMENT '0 for general\n1 for shifting',
  `shift_name` varchar(150) DEFAULT NULL,
  `shift_description` varchar(150) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `working_hours` time DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `valid` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date_status` int(11) DEFAULT NULL COMMENT '1 for 1 day\n2 for 2 day',
  `hrm_location_id` int(11) DEFAULT NULL,
  `shift_status` int(11) DEFAULT NULL COMMENT '0 for geraral shift\n1 for shifting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_shift_role`
--

CREATE TABLE `hrm_shift_role` (
  `id` int(11) NOT NULL,
  `shift_role_name` varchar(145) DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_shift_role_duration`
--

CREATE TABLE `hrm_shift_role_duration` (
  `id` int(11) NOT NULL,
  `hrm_shift_role_id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `valid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_shift_role_employee`
--

CREATE TABLE `hrm_shift_role_employee` (
  `id` int(11) NOT NULL,
  `hrm_shift_role_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_skill`
--

CREATE TABLE `hrm_skill` (
  `id` int(11) NOT NULL,
  `skill_name` varchar(85) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_skill_employeewise`
--

CREATE TABLE `hrm_skill_employeewise` (
  `id` int(11) NOT NULL,
  `hrm_skill_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `description` varchar(145) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `is_valid` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `punch_date` date DEFAULT NULL,
  `working_hour` time DEFAULT NULL,
  `in_datetime` datetime DEFAULT NULL,
  `out_datetime` datetime DEFAULT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `outside_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_ot`
--

CREATE TABLE `log_ot` (
  `id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL,
  `attandance_date` date DEFAULT NULL,
  `punch_time` time DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobile_log`
--

CREATE TABLE `mobile_log` (
  `id` int(10) NOT NULL,
  `lon` double DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `valid` int(11) NOT NULL DEFAULT 1,
  `hrm_employee_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `attachment` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `module_info`
--

CREATE TABLE `module_info` (
  `id` int(11) NOT NULL,
  `description` varchar(145) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay_register`
--

CREATE TABLE `pay_register` (
  `id` int(11) NOT NULL,
  `year_id` int(11) DEFAULT NULL,
  `hrm_month_id` int(11) NOT NULL,
  `day_of_month` double DEFAULT 0,
  `total_present` double DEFAULT 0,
  `salary_genarate_type` int(11) DEFAULT NULL COMMENT '0 for delete\n1 for prosses\n2 for genarate\n',
  `users_id` int(11) NOT NULL,
  `amount` double DEFAULT 0,
  `apply_for` int(11) DEFAULT NULL COMMENT '1 for salary Sheet\n2 for Other sheet\n3 for CW Sheet',
  `hrm_employee_salary_id` int(11) DEFAULT NULL,
  `hrm_employee_job_info_id` int(11) NOT NULL,
  `hrm_bank_id` int(11) DEFAULT NULL,
  `by_bank_percent` int(11) DEFAULT NULL,
  `account_no` varchar(45) DEFAULT NULL,
  `payment_mode` int(11) DEFAULT NULL,
  `hrm_salary_generate_master_id` int(11) DEFAULT NULL,
  `hrm_location_id` int(11) DEFAULT NULL,
  `accounts_code` varchar(45) DEFAULT NULL,
  `note` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay_register_cw`
--

CREATE TABLE `pay_register_cw` (
  `id` int(11) NOT NULL,
  `pay_register_id` int(11) NOT NULL,
  `adv_adjust` double DEFAULT NULL,
  `due_adjust` double DEFAULT NULL,
  `hrm_plant_with_section_id` int(11) NOT NULL,
  `actual_worked_days` int(11) DEFAULT NULL,
  `holiday_worked_days` int(11) DEFAULT NULL,
  `exceed_days` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay_register_cw_ot`
--

CREATE TABLE `pay_register_cw_ot` (
  `id` int(10) UNSIGNED NOT NULL,
  `hrm_attendance_id` int(11) DEFAULT NULL,
  `actual_overtime_time` time DEFAULT NULL,
  `hrm_employee_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay_register_details`
--

CREATE TABLE `pay_register_details` (
  `id` int(11) NOT NULL,
  `hrm_salary_head_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL,
  `amount_type` int(11) DEFAULT NULL COMMENT '1 for %\n2 for tk',
  `actual_amount` double DEFAULT NULL,
  `pay_register_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isActive` int(11) DEFAULT 1 COMMENT '1 for Active\n0 for deactive\n(Handle By Developer)',
  `guard_name` varchar(45) DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `permission_for` tinyint(4) DEFAULT NULL COMMENT '1 For Attendance\n2 For Payroll',
  `permission_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `isActive`, `guard_name`, `created_at`, `updated_at`, `permission_for`, `permission_id`) VALUES
(1, 'MainAdminOption', 'MainAdminOption', NULL, 1, 'web', '2018-06-09 03:30:01', '2018-06-09 03:30:01', 1, NULL),
(2, 'MainDashboardOption', 'MainDashboardOption', NULL, 1, 'web', '2018-07-17 22:16:40', '2018-07-17 22:16:40', 1, NULL),
(3, 'MainAttendanceOption', 'MainAttendanceOption', NULL, 1, 'web', '2018-07-17 22:20:54', '2018-07-17 22:20:54', 1, NULL),
(4, 'AdminConfiguration', 'AdminConfiguration', 'N/A', 1, 'web', '2016-07-18 06:03:00', '2016-07-18 06:03:00', 1, NULL),
(5, 'AdminEmployeeManagement', 'AdminEmployeeManagement', 'N/A', 1, 'web', '2016-07-18 06:03:00', '2016-07-18 06:03:00', 1, NULL),
(6, 'AdminSalaryConfiguration', 'AdminSalaryConfiguration', 'N/A', 1, 'web', '2016-07-18 06:03:00', '2016-07-18 06:03:00', 2, NULL),
(7, 'AddEmployee', 'AddEmployee', 'N/A', 1, 'web', '2016-07-18 06:03:00', '2015-07-18 06:03:00', 1, NULL),
(8, 'EmployeeJoin', 'EmployeeJoin', 'N/A', 1, 'web', '2017-07-18 06:03:00', '2016-07-18 06:03:00', 1, NULL),
(9, 'EmployeeCard', 'EmployeeCard', 'N/A', 1, 'web', '2018-07-18 06:03:00', '2017-07-18 06:03:00', 1, NULL),
(10, 'EmployeeQualification', 'EmployeeQualification', 'N/A', 1, 'web', '2019-07-18 06:03:00', '2018-07-18 06:03:00', 1, NULL),
(11, 'EmployeeTransfer', 'EmployeeTransfer', 'N/A', 1, 'web', '2020-07-18 06:03:00', '2019-07-18 06:03:00', 1, NULL),
(12, 'EmployeeResign', 'EmployeeResign', 'N/A', 1, 'web', '2021-07-18 06:03:00', '2020-07-18 06:03:00', 1, NULL),
(13, 'LocationSetup', 'LocationSetup', 'N/A', 1, 'web', '2022-07-18 06:03:00', '2021-07-18 06:03:00', 2, NULL),
(14, 'LeaveAplication', 'LeaveAplication', 'N/A', 1, 'web', '2024-07-18 06:03:00', '2023-07-18 06:03:00', 1, NULL),
(15, 'LeaveAproval', 'LeaveAproval', 'N/A', 1, 'web', '2025-07-18 06:03:00', '2024-07-18 06:03:00', 1, NULL),
(16, 'HolidayAgainstLeave', 'HolidayAgainstLeave', 'N/A', 1, 'web', '2026-07-18 06:03:00', '2025-07-18 06:03:00', 1, NULL),
(17, 'LeaveAplicationCreateDelete', 'LeaveAplicationCreateDelete', 'N/A', 1, 'web', '2027-07-18 06:03:00', '2026-07-18 06:03:00', 1, NULL),
(18, 'AttendanceList', 'AttendanceList', 'N/A', 1, 'web', '2028-07-18 06:03:00', '2027-07-18 06:03:00', 1, NULL),
(19, 'ManualAttendanceEntry', 'ManualAttendanceEntry', 'N/A', 1, 'web', '2029-07-18 06:03:00', '2028-07-18 06:03:00', 1, NULL),
(20, 'ManualTotalAttendanceInOut', 'ManualTotalAttendanceInOut', 'N/A', 1, 'web', '2030-07-18 06:03:00', '2029-07-18 06:03:00', 1, NULL),
(21, 'ManualOut', 'ManualOut', 'N/A', 1, 'web', '2031-07-18 06:03:00', '2030-07-18 06:03:00', 1, NULL),
(22, 'ManualOTEntry', 'ManualOTEntry', 'N/A', 1, 'web', '2001-08-18 06:03:00', '2031-07-18 06:03:00', 1, NULL),
(23, 'MainEmployeeShiftOption', 'MainEmployeeShiftOption', 'N/A', 1, 'web', '2002-08-18 06:03:00', '2001-08-18 06:03:00', 1, NULL),
(24, 'EmployeeShiftList', 'EmployeeShiftList', 'N/A', 1, 'web', '2003-08-18 06:03:00', '2002-08-18 06:03:00', 1, NULL),
(25, 'ShiftRoleApply', 'ShiftRoleApply', 'N/A', 1, 'web', '2004-08-18 06:03:00', '2003-08-18 06:03:00', 1, NULL),
(26, 'PreviosShiftChange', 'PreviosShiftChange', 'N/A', 1, 'web', '2005-08-18 06:03:00', '2004-08-18 06:03:00', 1, NULL),
(27, 'AttendanceLeaveManagementOption', 'AttendanceLeaveManagementOption', 'N/A', 1, 'web', '2006-08-18 06:03:00', '2005-08-18 06:03:00', 1, NULL),
(28, 'AttendanceDataUpload', 'AttendanceDataUpload', 'N/A', 1, 'web', '2007-08-18 06:03:00', '2006-08-18 06:03:00', 1, NULL),
(29, 'AttendanceProcess', 'AttendanceProcess', 'N/A', 1, 'web', '2008-08-18 06:03:00', '2007-08-18 06:03:00', 1, NULL),
(30, 'HolidaySetupProcessOption', 'HolidaySetupProcessOption', 'N/A', 1, 'web', '2009-08-18 05:03:00', '2008-08-18 06:03:00', 1, NULL),
(31, 'MainPayrollOption', 'MainPayrollOption', 'N/A', 1, 'web', '2010-08-18 06:03:00', '2009-08-18 05:03:00', 2, NULL),
(32, 'EmployeeSalary', 'EmployeeSalary', 'N/A', 1, 'web', '2011-08-18 06:03:00', '2010-08-18 06:03:00', 2, NULL),
(33, 'SalaryProcess', 'SalaryProcess', 'N/A', 1, 'web', '2012-08-18 06:03:00', '2011-08-18 06:03:00', 2, NULL),
(34, 'PayRegister', 'PayRegister', 'N/A', 1, 'web', '2013-08-18 06:03:00', '2012-08-18 06:03:00', 2, NULL),
(35, 'SalaryGenerate', 'SalaryGenerate', 'N/A', 1, 'web', '2014-08-18 06:03:00', '2013-08-18 06:03:00', 2, NULL),
(36, 'BonusGenerateOption', 'BonusGenerateOption', 'N/A', 1, 'web', '2015-08-18 06:03:00', '2014-08-18 06:03:00', 2, NULL),
(37, 'BonusProcess', 'BonusProcess', 'N/A', 1, 'web', '2016-08-18 06:03:00', '2015-08-18 06:03:00', 2, NULL),
(38, 'EmployeeBonus', 'EmployeeBonus', 'N/A', 1, 'web', '2017-08-18 06:03:00', '2016-08-18 06:03:00', 2, NULL),
(39, 'BonusGenerate', 'BonusGenerate', 'N/A', 1, 'web', '2018-08-18 06:03:00', '2017-08-18 06:03:00', 1, NULL),
(40, 'MainReportOption', 'MainReportOption', 'N/A', 1, 'web', '2019-08-18 06:03:00', '2018-08-18 06:03:00', 2, NULL),
(41, 'MainDocumentArchiveOption', 'MainDocumentArchiveOption', 'N/A', 1, 'web', '2020-08-18 06:03:00', '2019-08-18 06:03:00', 1, NULL),
(42, 'AdminUserManager', 'AdminUserManager', 'N/A', 1, 'web', '2021-08-18 06:03:00', '2020-08-18 06:03:00', 1, NULL),
(43, 'LoanAdvanceOption', 'LoanAdvanceOption', 'N/A', 1, 'web', '2023-08-18 06:03:00', '2022-08-18 06:03:00', 2, NULL),
(44, 'AttendanceManualOption', 'AttendanceManualOption', 'N/A', 1, 'web', '2024-08-18 06:03:00', '2023-08-18 06:03:00', 1, NULL),
(45, 'EditEmployeeInfo', 'EditEmployeeInfo', 'N/A', 1, 'web', '2025-08-18 06:03:00', '2024-08-18 06:03:00', 1, NULL),
(46, 'PrintEmployeeInfo', 'PrintEmployeeInfo', 'N/A', 1, 'web', '2026-08-18 06:03:00', '2025-08-18 06:03:00', 1, NULL),
(47, 'NewEmployeeCreateAndJoin', 'NewEmployeeCreateAndJoin', 'N/A', 1, 'web', '2027-08-18 06:03:00', '2026-08-18 06:03:00', 1, NULL),
(48, 'EmployeeCardCreateEditDelete', 'EmployeeCardCreateEditDelete', 'N/A', 1, 'web', '2028-08-18 06:03:00', '2027-08-18 06:03:00', 1, NULL),
(49, 'EmployeeResignCreate', 'EmployeeResignCreate', 'N/A', 1, 'web', '2029-08-18 06:03:00', '2028-08-18 06:03:00', 1, NULL),
(50, 'EmployeeResignApprove', 'EmployeeResignApprove', 'N/A', 1, 'web', '2030-08-18 06:03:00', '2029-08-18 06:03:00', 1, NULL),
(51, 'PlantConfigurationOption', 'PlantConfigurationOption', NULL, 1, 'web', '2018-09-18 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(52, 'HolidayConvertToWorkingOption', 'HolidayConvertToWorkingOption', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 1, NULL),
(53, 'OtherFacilityOption', 'OtherFacilityOption', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(54, 'OtherFacility', 'OtherFacility', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(55, 'OtherFacilityProcess', 'OtherFacilityProcess', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(56, 'OtherFacilityPayRegister', 'OtherFacilityPayRegister', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(57, 'OtherFacilityGenerate', 'OtherFacilityGenerate', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(58, 'CWSalaryGenerateOption', 'CWSalaryGenerateOption', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(59, 'CWSalaryProcess', 'CWSalaryProcess', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(60, 'CWPayRegister', 'CWPayRegister', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(61, 'CWSalaryGenerate', 'CWSalaryGenerate', NULL, 1, 'web', '2018-09-04 18:00:00', '2018-09-04 18:00:00', 2, NULL),
(62, 'SalaryExtraFeatures', 'SalaryExtraFeatures', NULL, 1, 'web', '2018-12-02 01:59:36', '2018-12-02 01:59:36', 2, NULL),
(63, 'ReportDailyAttendance', 'ReportDailyAttendance', NULL, 1, 'web', '2018-12-07 22:44:30', '2018-12-07 22:44:30', 1, NULL),
(64, 'ReportDepartmentWiseSummary', 'ReportDepartmentWiseSummary', NULL, 1, 'web', '2018-12-07 22:44:44', '2018-12-07 22:44:44', 1, NULL),
(65, 'ReportAttendanceMissingOut', 'ReportAttendanceMissingOut', NULL, 1, 'web', '2018-12-07 22:44:54', '2018-12-07 22:44:54', 1, NULL),
(66, 'ReportMonthlyAttendanceSummary', 'ReportMonthlyAttendanceSummary', NULL, 1, 'web', '2018-12-07 22:45:03', '2018-12-07 22:45:03', 1, NULL),
(67, 'ReportMonthlyAttendanceDetails', 'ReportMonthlyAttendanceDetails', NULL, 1, 'web', '2018-12-07 22:45:13', '2018-12-07 22:45:13', 1, NULL),
(68, 'ReportMonthlyOverTime', 'ReportMonthlyOverTime', NULL, 1, 'web', '2018-12-07 22:45:21', '2018-12-07 22:45:21', 1, NULL),
(69, 'ReportEmployeeWiseJobCard', 'ReportEmployeeWiseJobCard', NULL, 1, 'web', '2018-12-07 22:45:31', '2018-12-07 22:45:31', 1, NULL),
(70, 'ReportCategoryWiseEmployeeList', 'ReportCategoryWiseEmployeeList', NULL, 1, 'web', '2018-12-07 22:45:39', '2018-12-07 22:45:39', 1, NULL),
(71, 'ReportMonthlyOTSheet', 'ReportMonthlyOTSheet', NULL, 1, 'web', '2018-12-07 22:45:48', '2018-12-07 22:45:48', 1, NULL),
(72, 'ReportIndividualLeaveLedger', 'ReportIndividualLeaveLedger', NULL, 1, 'web', '2018-12-07 22:45:55', '2018-12-07 22:45:55', 1, NULL),
(73, 'ReportManPower', 'ReportManPower', NULL, 1, 'web', '2018-12-07 22:46:03', '2018-12-07 22:46:03', 1, NULL),
(74, 'ReportBloodGroupWise', 'ReportBloodGroupWise', NULL, 1, 'web', '2018-12-07 22:46:12', '2018-12-07 22:46:12', 1, NULL),
(75, 'ReportSalarySheet', 'ReportSalarySheet', NULL, 1, 'web', '2018-12-07 22:46:22', '2018-12-07 22:46:22', 2, NULL),
(76, 'ReportCWSalarySheet', 'ReportCWSalarySheet', NULL, 1, 'web', '2018-12-07 22:46:30', '2018-12-07 22:46:30', 2, NULL),
(77, 'ReportBonusSheet', 'ReportBonusSheet', NULL, 1, 'web', '2018-12-07 22:46:38', '2018-12-07 22:46:38', 2, NULL),
(78, 'ReportBankSalarySheet', 'ReportBankSalarySheet', NULL, 1, 'web', '2018-12-07 22:46:46', '2018-12-07 22:46:46', 2, NULL),
(79, 'ReportMonthlyHouseRent', 'ReportMonthlyHouseRent', NULL, 1, 'web', '2018-12-07 22:49:15', '2018-12-07 22:49:15', 2, NULL),
(80, 'ReportOutOfPocket', 'ReportOutOfPocket', NULL, 1, 'web', '2018-12-11 23:23:20', '2018-12-11 23:23:20', 2, NULL),
(81, 'ReportFixedAllowance', 'ReportFixedAllowance', NULL, 1, 'web', '2018-12-12 04:55:33', '2018-12-12 04:55:33', 2, NULL),
(82, 'ReportCarAllowance', 'ReportCarAllowance', NULL, 1, 'web', '2018-12-12 06:15:37', '2018-12-12 06:15:37', 2, NULL),
(83, 'ReportEmployeeLog', 'ReportEmployeeLog', NULL, 1, 'web', '2018-12-17 04:20:16', '2018-12-17 04:20:16', 1, NULL),
(84, 'DocumentArchiveFileTypeSetup', 'DocumentArchiveFileTypeSetup', NULL, 1, 'web', '2018-12-21 23:00:54', '2018-12-21 23:00:54', 1, NULL),
(85, 'redflag', 'Red Flag', NULL, 1, 'web', '2019-02-21 21:36:00', '2019-02-21 21:36:00', 1, NULL),
(87, 'AttendanceManualOTOption', 'AttendanceManualOTOption', 'AttendanceManualOTOption', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(88, 'ManualOTEntryAll', 'ManualOTEntryAll', 'ManualOTEntryAll', 0, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(89, 'AttendanceRawDataCheck', 'AttendanceRawDataCheck', 'AttendanceRawDataCheck', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(90, 'EmployeeShiftChange', 'EmployeeShiftChange', 'EmployeeShiftChange', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(91, 'EmployeeShiftChangeMultiple', 'EmployeeShiftChangeMultiple', 'EmployeeShiftChangeMultiple', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(92, 'ShiftRoleAssign', 'ShiftRoleAssign', 'ShiftRoleAssign', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(93, 'PayrollSalaryOption', 'PayrollSalaryOption', 'PayrollSalaryOption', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(94, 'PayrollCWSalaryOption', 'PayrollCWSalaryOption', 'PayrollCWSalaryOption', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(95, 'PayrollFringeBenefitsOption', 'PayrollFringeBenefitsOption', 'PayrollFringeBenefitsOption', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(96, 'PayrollBonusOption', 'PayrollBonusOption', 'PayrollBonusOption', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(97, 'PayrollLoanManagementOption', 'PayrollLoanManagementOption', 'PayrollLoanManagementOption', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(98, 'DocumentArchiveOwnOnly', 'DocumentArchiveOwnOnly', 'DocumentArchiveOwnOnly', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(99, 'EmployeePromotion', 'EmployeePromotion', 'EmployeePromotion', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 2, NULL),
(100, 'EmployeeInactive', 'EmployeeInactive', 'EmployeeInactive', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(101, 'EmployeeIdCardPrint', 'EmployeeIdCardPrint', 'EmployeeIdCardPrint', 1, 'web', '2019-06-19 18:00:00', '2019-06-19 18:00:00', 1, NULL),
(102, 'EmployeeIncrement', 'EmployeeIncrement', NULL, 1, 'web', '2019-08-21 10:31:35', '2019-08-21 10:31:35', 2, NULL),
(103, 'ReportMonthlyTopSheet', 'ReportMonthlyTopSheet', NULL, 1, 'web', '2020-01-02 04:32:37', '2020-01-02 04:32:37', 2, NULL),
(104, 'ReportSalaryHeadWise', 'ReportSalaryHeadWise', NULL, 1, 'web', '2020-01-02 04:32:50', '2020-01-02 04:32:50', 2, NULL),
(105, 'EmployeeLongService', 'EmployeeLongService', NULL, 1, 'web', '2020-01-20 02:09:54', '2020-01-20 02:09:54', 2, NULL),
(106, 'MainKPIOption', 'MainKPIOption', NULL, 1, 'web', '2020-02-16 02:35:42', '2020-02-16 02:35:42', 2, NULL),
(107, 'KPIAdminUser', 'KPIAdminUser', NULL, 1, 'web', '2020-06-04 05:22:47', '2020-06-04 05:22:47', 2, NULL),
(108, 'KPIUserOnly', 'KPIUserOnly', NULL, 1, 'web', '2020-06-04 05:26:50', '2020-06-04 05:26:50', 2, NULL),
(109, 'ReportSalaryReview', 'ReportSalaryReview', NULL, 1, 'web', '2020-07-18 17:07:12', '2020-07-18 17:07:12', 2, NULL),
(110, 'ReportFBSheet', 'ReportFBSheet', NULL, 1, 'web', '2020-08-22 05:18:33', '2020-08-22 05:18:33', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_module`
--

CREATE TABLE `permission_module` (
  `id` int(11) NOT NULL,
  `permissions_id` int(11) NOT NULL,
  `module_info_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `guard_name` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'Admin', 'Admin', 'web', '2022-01-01 04:11:00', '2022-01-01 04:11:00');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 1),
(78, 1),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(87, 1),
(89, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(94, 1),
(95, 1),
(96, 1),
(97, 1),
(98, 1),
(99, 1),
(100, 1),
(101, 1),
(102, 1),
(103, 1),
(104, 1),
(105, 1),
(106, 1),
(107, 1),
(108, 1),
(109, 1),
(110, 1);

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_employee_shift`
--

CREATE TABLE `tmp_employee_shift` (
  `process_date` date DEFAULT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `hrm_employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_hrm_attendance_data`
--

CREATE TABLE `tmp_hrm_attendance_data` (
  `id` int(11) NOT NULL,
  `attandance_date` date DEFAULT NULL,
  `punch_date` datetime DEFAULT NULL,
  `punch_time` time DEFAULT NULL,
  `data_from` int(11) DEFAULT NULL COMMENT '1ForPunchData\n2ForManualPunch\n3ForHolidayProcess\n',
  `row_data_id` int(11) DEFAULT NULL COMMENT 'as_hrm_attendance_raw_data_id',
  `hrm_employee_id` int(11) NOT NULL,
  `hrm_shift_id` int(11) NOT NULL,
  `punch_status` varchar(45) DEFAULT NULL COMMENT '0_for_In\n1_For_Out',
  `users_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(145) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `hrm_employee_id` int(11) DEFAULT NULL,
  `valid` int(11) DEFAULT 1,
  `user_type` tinyint(4) DEFAULT 1 COMMENT '1=GeneralUser\n2=SuperAdmin',
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(40) DEFAULT NULL,
  `created_by_users_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `designation`, `email`, `password`, `remember_token`, `hrm_employee_id`, `valid`, `user_type`, `last_login_at`, `last_login_ip`, `created_by_users_id`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'Officer', 'admin@admin.com', '$2y$10$ytqNceXWlbsfpB5tMUhIKOubdlaqWEFqE6oEBIJQOp/ttrPWdX4J.', NULL, 0, 1, 2, '2023-11-15 12:08:57', '127.0.0.1', 1, NULL, '2023-11-15 06:10:15');

-- --------------------------------------------------------

--
-- Table structure for table `user_location`
--

CREATE TABLE `user_location` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `hrm_location_id` int(11) NOT NULL,
  `default_location` int(11) DEFAULT NULL COMMENT '0 for permission\n1 for default '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_location`
--

INSERT INTO `user_location` (`id`, `users_id`, `hrm_location_id`, `default_location`) VALUES
(1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assigned_roles`
--
ALTER TABLE `assigned_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_assigned_roles_users1_idx` (`user_id`),
  ADD KEY `fk_assigned_roles_roles1_idx` (`role_id`);

--
-- Indexes for table `company_information`
--
ALTER TABLE `company_information`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_name_UNIQUE` (`company_name`);

--
-- Indexes for table `hrm_acc_exchange_emp`
--
ALTER TABLE `hrm_acc_exchange_emp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_exchange_emp_hrm_acc_head_title1_idx` (`hrm_acc_head_title_id`),
  ADD KEY `fk_hrm_acc_exchange_emp_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_acc_exchange_emp_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_acc_headwise_emp_tag`
--
ALTER TABLE `hrm_acc_headwise_emp_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_headwise_emp_tag_hrm_acc_head_title1_idx` (`hrm_acc_head_title_id`);

--
-- Indexes for table `hrm_acc_headwise_emp_tag_category`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_headwise_emp_tag_category_hrm_acc_headwise_emp_t_idx` (`hrm_acc_headwise_emp_tag_id`),
  ADD KEY `fk_hrm_acc_headwise_emp_tag_category_hrm_category1_idx` (`hrm_category_id`);

--
-- Indexes for table `hrm_acc_headwise_emp_tag_location`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_headwise_emp_tag_details_hrm_acc_headwise_emp_ta_idx` (`hrm_acc_headwise_emp_tag_id`);

--
-- Indexes for table `hrm_acc_headwise_emp_tag_salaryhead`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_salaryhead`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_headwise_emp_tag_salaryhead_hrm_acc_headwise_emp_idx` (`hrm_acc_headwise_emp_tag_id`),
  ADD KEY `fk_hrm_acc_headwise_emp_tag_salaryhead_hrm_salary_head1_idx` (`hrm_salary_head_id`);

--
-- Indexes for table `hrm_acc_head_integration`
--
ALTER TABLE `hrm_acc_head_integration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_head_integration_hrm_acc_head_title1_idx` (`hrm_acc_head_title_id`),
  ADD KEY `fk_hrm_acc_head_integration_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_acc_head_title`
--
ALTER TABLE `hrm_acc_head_title`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_acc_head_title_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_acc_head_title_hrm_acc_journal_type1_idx` (`hrm_acc_journal_type_id`);

--
-- Indexes for table `hrm_acc_journal_type`
--
ALTER TABLE `hrm_acc_journal_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_acc_processing_data_details`
--
ALTER TABLE `hrm_acc_processing_data_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_acc_processing_data_details_costcenter`
--
ALTER TABLE `hrm_acc_processing_data_details_costcenter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_asset`
--
ALTER TABLE `hrm_asset`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_asset_hrm_asset_type1_idx` (`asset_type_id`),
  ADD KEY `fk_hrm_asset_hrm_asset_brand1_idx` (`brand_id`);

--
-- Indexes for table `hrm_asset_assign_ledger`
--
ALTER TABLE `hrm_asset_assign_ledger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_assign_ledger_hrm_asset_assign_master1_idx` (`asset_assign_master_id`),
  ADD KEY `fk_hrm_asset_assign_ledger_hrm_asset1_idx` (`product_id`);

--
-- Indexes for table `hrm_asset_assign_master`
--
ALTER TABLE `hrm_asset_assign_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_assign_master_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_asset_assign_master_hrm_asset_store_master1_idx` (`hrm_asset_store_master_id`),
  ADD KEY `fk_hrm_asset_assign_master_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_asset_assign_master_hrm_depertment1_idx` (`hrm_depertment_id`);

--
-- Indexes for table `hrm_asset_brand`
--
ALTER TABLE `hrm_asset_brand`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_brand_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_asset_purchase_ledger`
--
ALTER TABLE `hrm_asset_purchase_ledger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_purchase_ledger_hrm_asset_purchase_master1_idx` (`asset_purchase_master_id`),
  ADD KEY `fk_hrm_asset_purchase_ledger_hrm_asset1_idx` (`product_id`);

--
-- Indexes for table `hrm_asset_purchase_master`
--
ALTER TABLE `hrm_asset_purchase_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_purchase_master_hrm_asset_store_master1_idx` (`asset_store_master_id`),
  ADD KEY `fk_hrm_asset_purchase_master_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_asset_return_master`
--
ALTER TABLE `hrm_asset_return_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_return_master_hrm_asset_assign_master1_idx` (`hrm_asset_assign_master_id`),
  ADD KEY `fk_hrm_asset_return_master_hrm_asset_store_master1_idx` (`hrm_asset_store_master_id`),
  ADD KEY `fk_hrm_asset_return_master_hrm_asset_return_type1_idx` (`hrm_asset_return_type_id`);

--
-- Indexes for table `hrm_asset_return_type`
--
ALTER TABLE `hrm_asset_return_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_return_type_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_asset_store_ledger`
--
ALTER TABLE `hrm_asset_store_ledger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_store_ledger_hrm_asset_store_master1_idx` (`asset_store_master_id`),
  ADD KEY `fk_hrm_asset_store_ledger_hrm_asset1_idx` (`product_id`);

--
-- Indexes for table `hrm_asset_store_master`
--
ALTER TABLE `hrm_asset_store_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_store_master_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_asset_type`
--
ALTER TABLE `hrm_asset_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_asset_type_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_attendance`
--
ALTER TABLE `hrm_attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_attendance_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_attendance_hrm_shift1_idx` (`hrm_shift_id`),
  ADD KEY `fk_hrm_attendance_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_attendance_comment`
--
ALTER TABLE `hrm_attendance_comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_attendance_data`
--
ALTER TABLE `hrm_attendance_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_attendance_data_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_attendance_data_hrm_shift1_idx` (`hrm_shift_id`);

--
-- Indexes for table `hrm_attendance_data_process_log`
--
ALTER TABLE `hrm_attendance_data_process_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_attendance_process_user_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_attendance_process_log_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_attendance_raw_data`
--
ALTER TABLE `hrm_attendance_raw_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_attendance_raw_data_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_attendance_raw_data_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `punch_date` (`punch_date`);

--
-- Indexes for table `hrm_attendance_status`
--
ALTER TABLE `hrm_attendance_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_bank`
--
ALTER TABLE `hrm_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_blood_group`
--
ALTER TABLE `hrm_blood_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_bonus`
--
ALTER TABLE `hrm_bonus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_category`
--
ALTER TABLE `hrm_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_category_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_change_employee_shift`
--
ALTER TABLE `hrm_change_employee_shift`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_change_employee_shift_hrm_shift1_idx` (`hrm_shift_id`),
  ADD KEY `fk_hrm_change_employee_shift_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_custom_filter`
--
ALTER TABLE `hrm_custom_filter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_custom_filter_details`
--
ALTER TABLE `hrm_custom_filter_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_custom_filter_details_hrm_custom_filter_master1_idx` (`hrm_custom_filter_master_id`);

--
-- Indexes for table `hrm_custom_filter_master`
--
ALTER TABLE `hrm_custom_filter_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_custom_filter_master_hrm_custom_filter1_idx` (`hrm_custom_filter_id`),
  ADD KEY `fk_hrm_custom_filter_master_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_cv_compensation`
--
ALTER TABLE `hrm_cv_compensation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_compensation_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_cv_drop_details`
--
ALTER TABLE `hrm_cv_drop_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_drop_details_hrm_cv_drop_master1_idx` (`hrm_cv_drop_master_id`),
  ADD KEY `fk_hrm_cv_drop_details_hrm_cv_job_requsition_details1_idx` (`hrm_cv_job_requsition_details_id`);

--
-- Indexes for table `hrm_cv_drop_master`
--
ALTER TABLE `hrm_cv_drop_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_drop_master_hrm_cv_job_requsition1_idx` (`hrm_cv_job_requsition_id`);

--
-- Indexes for table `hrm_cv_job_description`
--
ALTER TABLE `hrm_cv_job_description`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_job_description_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_cv_job_description_hrm_cv_job_description_group1_idx` (`hrm_cv_job_description_group_id`),
  ADD KEY `fk_hrm_cv_job_description_hrm_depertment1_idx` (`hrm_depertment_id`);

--
-- Indexes for table `hrm_cv_job_description_group`
--
ALTER TABLE `hrm_cv_job_description_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_cv_job_requsition`
--
ALTER TABLE `hrm_cv_job_requsition`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_job_requsition_hrm_depertment1_idx` (`hrm_depertment_id`),
  ADD KEY `fk_hrm_cv_job_requsition_hrm_designation1_idx` (`hrm_designation_id`),
  ADD KEY `fk_hrm_cv_job_requsition_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_cv_job_requsition_users2_idx` (`approved_by_users_id`);

--
-- Indexes for table `hrm_cv_job_requsition_compensation`
--
ALTER TABLE `hrm_cv_job_requsition_compensation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_job_requsition_compensation_hrm_cv_compensation1_idx` (`hrm_cv_compensation_id`),
  ADD KEY `fk_hrm_cv_job_requsition_compensation_hrm_cv_job_requsition_idx` (`hrm_cv_job_requsition_id`);

--
-- Indexes for table `hrm_cv_job_requsition_details`
--
ALTER TABLE `hrm_cv_job_requsition_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_cv_job_requsition_details_hrm_cv_job_description1_idx` (`hrm_cv_job_description_id`),
  ADD KEY `fk_hrm_cv_job_requsition_details_hrm_cv_job_requsition1_idx` (`hrm_cv_job_requsition_id`);

--
-- Indexes for table `hrm_days_name`
--
ALTER TABLE `hrm_days_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_default_head`
--
ALTER TABLE `hrm_default_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_deleted_data_log`
--
ALTER TABLE `hrm_deleted_data_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_deleted_data_log_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_depertment`
--
ALTER TABLE `hrm_depertment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_depertment_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_designation`
--
ALTER TABLE `hrm_designation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_designation_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_device_information`
--
ALTER TABLE `hrm_device_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_education`
--
ALTER TABLE `hrm_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_eligible_ot_employee`
--
ALTER TABLE `hrm_eligible_ot_employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_eligible_ot_pending`
--
ALTER TABLE `hrm_eligible_ot_pending`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employee`
--
ALTER TABLE `hrm_employee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_hrm_blood_group1_idx` (`hrm_blood_group_id`),
  ADD KEY `fk_hrm_employee_hrm_religion1_idx` (`hrm_religion_id`),
  ADD KEY `fk_hrm_employee_hrm_marital_status1_idx` (`hrm_marital_status_id`),
  ADD KEY `fk_hrm_employee_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_employee_hrm_education1_idx` (`hrm_education_id`);

--
-- Indexes for table `hrm_employee_activity`
--
ALTER TABLE `hrm_employee_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_activity_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_employee_activity_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_employee_activity_hrm_employee_activity_status1_idx` (`hrm_employee_activity_status_id`);

--
-- Indexes for table `hrm_employee_activity_status`
--
ALTER TABLE `hrm_employee_activity_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employee_bonus`
--
ALTER TABLE `hrm_employee_bonus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_bonus_hrm_bonus1_idx` (`hrm_bonus_id`),
  ADD KEY `fk_hrm_employee_bonus_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_employee_bonus_cw`
--
ALTER TABLE `hrm_employee_bonus_cw`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_bonus_cw_hrm_employee_bonus_master1_idx` (`hrm_employee_bonus_master_id`);

--
-- Indexes for table `hrm_employee_bonus_master`
--
ALTER TABLE `hrm_employee_bonus_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_bonus_master_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_employee_bonus_master_hrm_bonus1_idx` (`hrm_bonus_id`),
  ADD KEY `fk_hrm_employee_bonus_master_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_employee_card_code`
--
ALTER TABLE `hrm_employee_card_code`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_card_code_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_employee_card_code_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`);

--
-- Indexes for table `hrm_employee_draft`
--
ALTER TABLE `hrm_employee_draft`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employee_file`
--
ALTER TABLE `hrm_employee_file`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_file_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_employee_file_hrm_file_type1_idx` (`hrm_file_type_id`);

--
-- Indexes for table `hrm_employee_holiday`
--
ALTER TABLE `hrm_employee_holiday`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_holiday_hrm_holiday1_idx` (`hrm_holiday_id`),
  ADD KEY `fk_hrm_employee_holiday_hrm_leave_years1_idx` (`hrm_leave_years_id`),
  ADD KEY `fk_hrm_employee_holiday_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_employee_holiday_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_holiday_details`
--
ALTER TABLE `hrm_employee_holiday_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_holiday_details_hrm_employee_holiday1_idx` (`hrm_employee_holiday_id`),
  ADD KEY `fk_hrm_employee_holiday_details_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_employee_inactive`
--
ALTER TABLE `hrm_employee_inactive`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_inactive_employee_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_inactive_employee_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_job_approval`
--
ALTER TABLE `hrm_employee_job_approval`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_job_approval_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_employee_job_approval_users1_idx` (`job_users_id`),
  ADD KEY `fk_hrm_employee_job_approval_users2_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_job_info`
--
ALTER TABLE `hrm_employee_job_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_depertment1_idx` (`hrm_depertment_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_designation1_idx` (`hrm_designation_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_category1_idx` (`hrm_category_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_employment_status1_idx` (`hrm_employment_status_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_employee2_idx` (`hrm_manage_by_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_employee_job_info_hrm_section1_idx` (`hrm_section_id`),
  ADD KEY `fk_hrm_employee_job_info_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_job_info_draft`
--
ALTER TABLE `hrm_employee_job_info_draft`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employee_joining`
--
ALTER TABLE `hrm_employee_joining`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_joining_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_employee_leave_type`
--
ALTER TABLE `hrm_employee_leave_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employee_leave_year`
--
ALTER TABLE `hrm_employee_leave_year`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_leave_year_hrm_leave_years1_idx` (`hrm_leave_years_id`),
  ADD KEY `fk_hrm_employee_leave_year_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_employee_leave_year_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_long_service`
--
ALTER TABLE `hrm_employee_long_service`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_long_service_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_employee_long_service_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_probation`
--
ALTER TABLE `hrm_employee_probation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_probation_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_employee_probation_hrm_probation_period1_idx` (`hrm_probation_period_id`),
  ADD KEY `fk_hrm_employee_probation_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_resignation`
--
ALTER TABLE `hrm_employee_resignation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_resignation_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_employee_resignation_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_employee_salary`
--
ALTER TABLE `hrm_employee_salary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_salary_hrm_salary_grade_master1_idx` (`hrm_salary_grade_master_id`),
  ADD KEY `fk_hrm_employee_salary_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_employee_salary_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_employee_salary_hrm_bank1_idx` (`hrm_bank_id`);

--
-- Indexes for table `hrm_employee_salary_details`
--
ALTER TABLE `hrm_employee_salary_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_salary_details_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_hrm_employee_salary_details_hrm_employee_salary1_idx` (`hrm_employee_salary_id`);

--
-- Indexes for table `hrm_employee_shift`
--
ALTER TABLE `hrm_employee_shift`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_shift_hrm_shift1_idx` (`hrm_shift_id`),
  ADD KEY `fk_hrm_employee_shift_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`);

--
-- Indexes for table `hrm_employee_shift_auto`
--
ALTER TABLE `hrm_employee_shift_auto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employee_task`
--
ALTER TABLE `hrm_employee_task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_task_hrm_employee_task_type1_idx` (`hrm_employee_task_type_id`);

--
-- Indexes for table `hrm_employee_task_assign`
--
ALTER TABLE `hrm_employee_task_assign`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_task_assign_hrm_employee_task1_idx` (`hrm_employee_task_id`),
  ADD KEY `fk_hrm_employee_task_assign_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_employee_task_complete`
--
ALTER TABLE `hrm_employee_task_complete`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_task_complete_hrm_employee_task_assign1_idx` (`hrm_employee_task_assign_id`);

--
-- Indexes for table `hrm_employee_task_type`
--
ALTER TABLE `hrm_employee_task_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_employment_status`
--
ALTER TABLE `hrm_employment_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_favourite_link`
--
ALTER TABLE `hrm_favourite_link`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_favourite_link_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_file_type`
--
ALTER TABLE `hrm_file_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_fringe_benefits_config`
--
ALTER TABLE `hrm_fringe_benefits_config`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fringe_benefits_config_hrm_designation1_idx` (`hrm_designation_id`),
  ADD KEY `fk_fringe_benefits_config_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_fringe_benefits_config_details`
--
ALTER TABLE `hrm_fringe_benefits_config_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fringe_benefits_config_details_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_hrm_fringe_benefits_config_details_hrm_fringe_benefits_c_idx` (`hrm_fringe_benefits_config_id`);

--
-- Indexes for table `hrm_holiday`
--
ALTER TABLE `hrm_holiday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_holidayconvert_to_working`
--
ALTER TABLE `hrm_holidayconvert_to_working`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_holidayconvert_to_working_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_holidayconvert_to_working_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_holiday_against_leave`
--
ALTER TABLE `hrm_holiday_against_leave`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_holiday_agents_leave_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_holiday_agents_leave_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_holiday_configure`
--
ALTER TABLE `hrm_holiday_configure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_holiday_configure_hrm_days_name1_idx` (`hrm_days_name_id`),
  ADD KEY `fk_hrm_holiday_configure_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_holiday_configure_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_holiday_configure_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_kpi_assesment_date`
--
ALTER TABLE `hrm_kpi_assesment_date`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_assesment_date_hrm_kpi_assesment_year1_idx` (`hrm_kpi_assesment_year_id`),
  ADD KEY `fk_hrm_kpi_assesment_date_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_assesment_year`
--
ALTER TABLE `hrm_kpi_assesment_year`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_assesment_year_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_deduction_mark`
--
ALTER TABLE `hrm_kpi_deduction_mark`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_deduction_mark_hrm_file_type1_idx` (`hrm_file_type_id`),
  ADD KEY `fk_hrm_kpi_deduction_mark_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_kpi_deduction_mark_hrm_kpi_assesment_date1_idx` (`hrm_kpi_assesment_date_id`);

--
-- Indexes for table `hrm_kpi_dept_head_assign_details`
--
ALTER TABLE `hrm_kpi_dept_head_assign_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_dept_head_assign_details_hrm_kpi_dept_head_assig_idx` (`hrm_kpi_dept_head_assign_master_id`),
  ADD KEY `fk_hrm_kpi_dept_head_assign_details_hrm_depertment1_idx` (`hrm_depertment_id`);

--
-- Indexes for table `hrm_kpi_dept_head_assign_master`
--
ALTER TABLE `hrm_kpi_dept_head_assign_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_dept_head_assign_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_kpi_dept_head_assign_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_kpi_dept_head_assign_hrm_kpi_assesment_date1_idx` (`hrm_kpi_assesment_date_id`),
  ADD KEY `fk_hrm_kpi_dept_head_assign_master_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_kpi_dynamic_table`
--
ALTER TABLE `hrm_kpi_dynamic_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_kpi_employee_details`
--
ALTER TABLE `hrm_kpi_employee_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_employee_details_hrm_kpi_task_details1_idx` (`hrm_kpi_task_details_id`),
  ADD KEY `fk_hrm_kpi_employee_details_hrm_kpi_marks1_idx` (`hrm_kpi_marks_id`),
  ADD KEY `fk_hrm_kpi_employee_details_hrm_kpi_employee_master1_idx` (`hrm_kpi_employee_master_id`);

--
-- Indexes for table `hrm_kpi_employee_final_summary`
--
ALTER TABLE `hrm_kpi_employee_final_summary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_employee_final_summary_hrm_kpi_employee_master1_idx` (`hrm_kpi_employee_master_id`),
  ADD KEY `fk_hrm_kpi_employee_final_summary_hrm_kpi_increment_range1_idx` (`hrm_kpi_increment_range_id`),
  ADD KEY `fk_hrm_kpi_employee_final_summary_hrm_kpi_increment_range2_idx` (`hrm_kpi_promotion_range_id`);

--
-- Indexes for table `hrm_kpi_employee_mark_deduct`
--
ALTER TABLE `hrm_kpi_employee_mark_deduct`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_employee_mark_deduct_hrm_kpi_employee_master1_idx` (`hrm_kpi_employee_master_id`),
  ADD KEY `fk_hrm_kpi_employee_mark_deduct_hrm_file_type1_idx` (`hrm_file_type_id`);

--
-- Indexes for table `hrm_kpi_employee_master`
--
ALTER TABLE `hrm_kpi_employee_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_employee_kpi_hrm_kpi_assesment_date1_idx` (`hrm_kpi_assesment_date_id`),
  ADD KEY `fk_hrm_kpi_employee_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`);

--
-- Indexes for table `hrm_kpi_increment_range`
--
ALTER TABLE `hrm_kpi_increment_range`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_increment_range_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_kpi_increment_range_hrm_kpi_assesment_date1_idx` (`hrm_kpi_assesment_date_id`);

--
-- Indexes for table `hrm_kpi_marks`
--
ALTER TABLE `hrm_kpi_marks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_marks_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_kpi_marks_hrm_kpi_set_config1_idx` (`hrm_kpi_set_config_id`);

--
-- Indexes for table `hrm_kpi_set_config`
--
ALTER TABLE `hrm_kpi_set_config`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_config_hrm_kpi_assesment_date1_idx` (`hrm_kpi_assesment_date_id`),
  ADD KEY `fk_hrm_kpi_set_config_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_set_config_department`
--
ALTER TABLE `hrm_kpi_set_config_department`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_config_department_hrm_depertment1_idx` (`hrm_depertment_id`),
  ADD KEY `fk_hrm_kpi_config_department_hrm_kpi_set_config1_idx` (`hrm_kpi_set_config_id`),
  ADD KEY `fk_hrm_kpi_set_config_department_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_set_config_dept_with`
--
ALTER TABLE `hrm_kpi_set_config_dept_with`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_set_config_dept_with_hrm_kpi_set_config_departme_idx` (`hrm_kpi_set_config_department_id`),
  ADD KEY `fk_hrm_kpi_set_config_dept_with_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_task`
--
ALTER TABLE `hrm_kpi_task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_task_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_kpi_task_hrm_kpi_task_type1_idx` (`hrm_kpi_task_type_id`);

--
-- Indexes for table `hrm_kpi_task_department`
--
ALTER TABLE `hrm_kpi_task_department`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_task_department_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_task_department_details`
--
ALTER TABLE `hrm_kpi_task_department_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_task_department_details_hrm_depertment1_idx` (`hrm_depertment_id`),
  ADD KEY `fk_hrm_kpi_task_department_details_hrm_kpi_task_department1_idx` (`hrm_kpi_task_department_id`);

--
-- Indexes for table `hrm_kpi_task_details`
--
ALTER TABLE `hrm_kpi_task_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_task_details_hrm_kpi_task1_idx` (`hrm_kpi_task_id`),
  ADD KEY `fk_hrm_kpi_task_details_hrm_kpi_task_department1_idx` (`hrm_kpi_task_department_id`),
  ADD KEY `fk_hrm_kpi_task_details_hrm_kpi_set_config1_idx` (`hrm_kpi_set_config_id`),
  ADD KEY `fk_hrm_kpi_task_details_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_kpi_task_type`
--
ALTER TABLE `hrm_kpi_task_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_kpi_task_type_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_last_promotion`
--
ALTER TABLE `hrm_last_promotion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_last_promotion_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_last_promotion_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_leave_application`
--
ALTER TABLE `hrm_leave_application`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_leave_application_hrm_employee_leave_type1_idx` (`hrm_employee_leave_type_id`),
  ADD KEY `fk_hrm_leave_application_hrm_leave_years1_idx` (`hrm_leave_years_id`),
  ADD KEY `fk_hrm_leave_application_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_leave_approve`
--
ALTER TABLE `hrm_leave_approve`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_leave_approve_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_leave_approve_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_leave_approve_hrm_leave_application1_idx` (`hrm_leave_application_id`);

--
-- Indexes for table `hrm_leave_ledger`
--
ALTER TABLE `hrm_leave_ledger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_leave_ledger_hrm_leave_approve1_idx` (`hrm_leave_approve_id`),
  ADD KEY `fk_hrm_leave_ledger_hrm_leave_years1_idx` (`hrm_leave_years_id`),
  ADD KEY `fk_hrm_leave_ledger_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_leave_ledger_hrm_employee_leave_type1_idx` (`hrm_employee_leave_type_id`),
  ADD KEY `fk_hrm_leave_ledger_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_leave_type_year`
--
ALTER TABLE `hrm_leave_type_year`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_leave_type_year_hrm_leave_years1_idx` (`hrm_leave_years_id`),
  ADD KEY `fk_hrm_leave_type_year_hrm_employee_leave_type1_idx` (`hrm_employee_leave_type_id`);

--
-- Indexes for table `hrm_leave_years`
--
ALTER TABLE `hrm_leave_years`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_loan_application`
--
ALTER TABLE `hrm_loan_application`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_loan_application_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_loan_application_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_loan_application_hrm_loan_type1_idx` (`hrm_loan_type_id`);

--
-- Indexes for table `hrm_loan_ledger`
--
ALTER TABLE `hrm_loan_ledger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_loan_ledger_hrm_loan_application1_idx` (`hrm_loan_application_id`),
  ADD KEY `fk_hrm_loan_ledger_hrm_month1_idx` (`hrm_month_id`),
  ADD KEY `fk_hrm_loan_ledger_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_loan_payregister_details`
--
ALTER TABLE `hrm_loan_payregister_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_loan_payregister_details_hrm_loan_application1_idx` (`hrm_loan_application_id`),
  ADD KEY `fk_hrm_loan_payregister_details_pay_register_details1_idx` (`pay_register_details_id`);

--
-- Indexes for table `hrm_loan_type`
--
ALTER TABLE `hrm_loan_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_loan_type_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_hrm_loan_type_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_location`
--
ALTER TABLE `hrm_location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_location_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_location_interval`
--
ALTER TABLE `hrm_location_interval`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_location_interval_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_manual_ot`
--
ALTER TABLE `hrm_manual_ot`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_manual_ot_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_manual_ot_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_manual_ot_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_marital_status`
--
ALTER TABLE `hrm_marital_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_month`
--
ALTER TABLE `hrm_month`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_mynote`
--
ALTER TABLE `hrm_mynote`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_mynote_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_organogram`
--
ALTER TABLE `hrm_organogram`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_organogram_hrm_designation_idx` (`hrm_designation_id`),
  ADD KEY `fk_hrm_organogram_hrm_designation1_idx` (`hrm_parent_id`),
  ADD KEY `fk_hrm_organogram_hrm_depertment1_idx` (`hrm_depertment_id`);

--
-- Indexes for table `hrm_ot_process_details`
--
ALTER TABLE `hrm_ot_process_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_ot_process_details_hrm_ot_process_master1_idx` (`hrm_ot_process_master_id`),
  ADD KEY `fk_hrm_ot_process_details_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`);

--
-- Indexes for table `hrm_ot_process_master`
--
ALTER TABLE `hrm_ot_process_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_ot_process_master_hrm_month1_idx` (`hrm_month_id`),
  ADD KEY `fk_hrm_ot_process_master_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_ot_process_master_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_ot_time`
--
ALTER TABLE `hrm_ot_time`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_ot_time_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_ot_time_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_plant`
--
ALTER TABLE `hrm_plant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_plantwise_employee`
--
ALTER TABLE `hrm_plantwise_employee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_plantwise_employee_hrm_plant1_idx` (`hrm_plant_id`),
  ADD KEY `fk_hrm_plantwise_employee_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_plantwise_employee_hrm_plant_with_section1_idx` (`hrm_plant_with_section_id`);

--
-- Indexes for table `hrm_plant_details`
--
ALTER TABLE `hrm_plant_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_plant_details_hrm_plant1_idx` (`hrm_plant_id`),
  ADD KEY `fk_hrm_plant_details_hrm_month1_idx` (`hrm_month_id`),
  ADD KEY `fk_hrm_plant_details_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_plant_details_hrm_plant_with_section1_idx` (`hrm_plant_with_section_id`);

--
-- Indexes for table `hrm_plant_with_section`
--
ALTER TABLE `hrm_plant_with_section`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_plant_with_section_hrm_plant1_idx` (`hrm_plant_id`),
  ADD KEY `fk_hrm_plant_with_section_hrm_section1_idx` (`hrm_section_id`),
  ADD KEY `fk_hrm_plant_with_section_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_probation_period`
--
ALTER TABLE `hrm_probation_period`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_redflag`
--
ALTER TABLE `hrm_redflag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_redflag_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_redflag_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_religion`
--
ALTER TABLE `hrm_religion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_salary_deduction`
--
ALTER TABLE `hrm_salary_deduction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_deduction_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_hrm_salary_deduction_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_salary_extra_feature`
--
ALTER TABLE `hrm_salary_extra_feature`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_extra_feature_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_hrm_salary_extra_feature_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_salary_extra_feature_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_salary_extra_feature_details`
--
ALTER TABLE `hrm_salary_extra_feature_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_extra_feature_details_hrm_salary_extra_featur_idx` (`hrm_salary_extra_feature_id`),
  ADD KEY `fk_hrm_salary_extra_feature_details_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`);

--
-- Indexes for table `hrm_salary_generate_master`
--
ALTER TABLE `hrm_salary_generate_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_generate_master_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_salary_generate_master_hrm_month1_idx` (`hrm_month_id`),
  ADD KEY `fk_hrm_salary_generate_master_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_salary_grade`
--
ALTER TABLE `hrm_salary_grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_salary_grade_details`
--
ALTER TABLE `hrm_salary_grade_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_grade_details_hrm_salary_grade_master1_idx` (`hrm_salary_grade_master_id`),
  ADD KEY `fk_hrm_salary_grade_details_hrm_salary_head1_idx` (`hrm_salary_head_id`);

--
-- Indexes for table `hrm_salary_grade_master`
--
ALTER TABLE `hrm_salary_grade_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_grade_master_hrm_salary_grade1_idx` (`hrm_salary_grade_id`);

--
-- Indexes for table `hrm_salary_head`
--
ALTER TABLE `hrm_salary_head`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_head_hrm_salary_Head_group1_idx` (`hrm_salary_head_group_id`),
  ADD KEY `fk_hrm_salary_head_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_salary_head_group`
--
ALTER TABLE `hrm_salary_head_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_salary_increment`
--
ALTER TABLE `hrm_salary_increment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_increment_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_hrm_salary_increment_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_salary_increment_details`
--
ALTER TABLE `hrm_salary_increment_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_increment_details_hrm_salary_increment1_idx` (`hrm_salary_increment_id`),
  ADD KEY `fk_hrm_salary_increment_details_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_hrm_salary_increment_details_hrm_designation1_idx` (`hrm_designation_id`);

--
-- Indexes for table `hrm_salary_slap`
--
ALTER TABLE `hrm_salary_slap`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_salary_slap_hrm_month1_idx` (`hrm_month_id`),
  ADD KEY `fk_hrm_salary_slap_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_section`
--
ALTER TABLE `hrm_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_set_default_head`
--
ALTER TABLE `hrm_set_default_head`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_set_default_head_hrm_default_head1_idx` (`hrm_default_head_id`),
  ADD KEY `fk_hrm_set_default_head_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_hrm_set_default_head_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_set_pf_confiq`
--
ALTER TABLE `hrm_set_pf_confiq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_set_pf_confiq_hrm_default_head1_idx` (`hrm_default_head_id_own`),
  ADD KEY `fk_hrm_set_pf_confiq_users1_idx` (`users_id`),
  ADD KEY `fk_hrm_set_pf_confiq_hrm_default_head2_idx` (`hrm_default_head_id_company`);

--
-- Indexes for table `hrm_shift`
--
ALTER TABLE `hrm_shift`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_shift_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_shift_role`
--
ALTER TABLE `hrm_shift_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_shift_role_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `hrm_shift_role_duration`
--
ALTER TABLE `hrm_shift_role_duration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_shift_role_duration_hrm_shift_role1_idx` (`hrm_shift_role_id`),
  ADD KEY `fk_hrm_shift_role_duration_hrm_shift1_idx` (`hrm_shift_id`);

--
-- Indexes for table `hrm_shift_role_employee`
--
ALTER TABLE `hrm_shift_role_employee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_shift_role_employee_hrm_shift_role1_idx` (`hrm_shift_role_id`),
  ADD KEY `fk_hrm_shift_role_employee_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `hrm_skill`
--
ALTER TABLE `hrm_skill`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_skill_users1_idx` (`users_id`);

--
-- Indexes for table `hrm_skill_employeewise`
--
ALTER TABLE `hrm_skill_employeewise`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hrm_skill_employeewise_hrm_skill1_idx` (`hrm_skill_id`),
  ADD KEY `fk_hrm_skill_employeewise_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_hrm_skill_employeewise_users1_idx` (`users_id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_log_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_log_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `log_ot`
--
ALTER TABLE `log_ot`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_log_ot_hrm_employee1_idx` (`hrm_employee_id`),
  ADD KEY `fk_log_ot_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `mobile_log`
--
ALTER TABLE `mobile_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `module_info`
--
ALTER TABLE `module_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_register`
--
ALTER TABLE `pay_register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pay_register_hrm_month1_idx` (`hrm_month_id`),
  ADD KEY `fk_pay_register_users1_idx` (`users_id`),
  ADD KEY `fk_pay_register_hrm_employee_job_info1_idx` (`hrm_employee_job_info_id`),
  ADD KEY `fk_pay_register_hrm_salary_generate_master1_idx` (`hrm_salary_generate_master_id`),
  ADD KEY `fk_pay_register_hrm_location1_idx` (`hrm_location_id`);

--
-- Indexes for table `pay_register_cw`
--
ALTER TABLE `pay_register_cw`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pay_register_cw_pay_register1_idx` (`pay_register_id`),
  ADD KEY `fk_pay_register_cw_hrm_plant_with_section1_idx` (`hrm_plant_with_section_id`);

--
-- Indexes for table `pay_register_cw_ot`
--
ALTER TABLE `pay_register_cw_ot`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_register_details`
--
ALTER TABLE `pay_register_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pay_register_details_hrm_salary_head1_idx` (`hrm_salary_head_id`),
  ADD KEY `fk_pay_register_details_pay_register1_idx` (`pay_register_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`);

--
-- Indexes for table `permission_module`
--
ALTER TABLE `permission_module`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_permission_module_permissions1_idx` (`permissions_id`),
  ADD KEY `fk_permission_module_module_info1_idx` (`module_info_id`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD KEY `fk_permission_role_permissions1_idx` (`permission_id`),
  ADD KEY `fk_permission_role_roles1_idx` (`role_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD KEY `fk_role_user_users1_idx` (`user_id`),
  ADD KEY `fk_role_user_roles1_idx` (`role_id`);

--
-- Indexes for table `tmp_employee_shift`
--
ALTER TABLE `tmp_employee_shift`
  ADD KEY `fk_tmp_employee_shift_hrm_location1_idx` (`hrm_location_id`),
  ADD KEY `fk_tmp_employee_shift_hrm_shift1_idx` (`hrm_shift_id`),
  ADD KEY `fk_tmp_employee_shift_hrm_employee1_idx` (`hrm_employee_id`);

--
-- Indexes for table `tmp_hrm_attendance_data`
--
ALTER TABLE `tmp_hrm_attendance_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`);

--
-- Indexes for table `user_location`
--
ALTER TABLE `user_location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_location_users1_idx` (`users_id`),
  ADD KEY `fk_user_location_hrm_location1_idx` (`hrm_location_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assigned_roles`
--
ALTER TABLE `assigned_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company_information`
--
ALTER TABLE `company_information`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_headwise_emp_tag`
--
ALTER TABLE `hrm_acc_headwise_emp_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_headwise_emp_tag_category`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_headwise_emp_tag_location`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_location`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_headwise_emp_tag_salaryhead`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_salaryhead`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_head_integration`
--
ALTER TABLE `hrm_acc_head_integration`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_head_title`
--
ALTER TABLE `hrm_acc_head_title`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_journal_type`
--
ALTER TABLE `hrm_acc_journal_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_processing_data_details`
--
ALTER TABLE `hrm_acc_processing_data_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_acc_processing_data_details_costcenter`
--
ALTER TABLE `hrm_acc_processing_data_details_costcenter`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset`
--
ALTER TABLE `hrm_asset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_assign_ledger`
--
ALTER TABLE `hrm_asset_assign_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_assign_master`
--
ALTER TABLE `hrm_asset_assign_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_brand`
--
ALTER TABLE `hrm_asset_brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_purchase_ledger`
--
ALTER TABLE `hrm_asset_purchase_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_purchase_master`
--
ALTER TABLE `hrm_asset_purchase_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_return_master`
--
ALTER TABLE `hrm_asset_return_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_return_type`
--
ALTER TABLE `hrm_asset_return_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_store_ledger`
--
ALTER TABLE `hrm_asset_store_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_store_master`
--
ALTER TABLE `hrm_asset_store_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_asset_type`
--
ALTER TABLE `hrm_asset_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendance`
--
ALTER TABLE `hrm_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendance_comment`
--
ALTER TABLE `hrm_attendance_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendance_data`
--
ALTER TABLE `hrm_attendance_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendance_data_process_log`
--
ALTER TABLE `hrm_attendance_data_process_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendance_raw_data`
--
ALTER TABLE `hrm_attendance_raw_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendance_status`
--
ALTER TABLE `hrm_attendance_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_bank`
--
ALTER TABLE `hrm_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_blood_group`
--
ALTER TABLE `hrm_blood_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `hrm_bonus`
--
ALTER TABLE `hrm_bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_category`
--
ALTER TABLE `hrm_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `hrm_change_employee_shift`
--
ALTER TABLE `hrm_change_employee_shift`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_custom_filter`
--
ALTER TABLE `hrm_custom_filter`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_custom_filter_details`
--
ALTER TABLE `hrm_custom_filter_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_custom_filter_master`
--
ALTER TABLE `hrm_custom_filter_master`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_compensation`
--
ALTER TABLE `hrm_cv_compensation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_drop_details`
--
ALTER TABLE `hrm_cv_drop_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_drop_master`
--
ALTER TABLE `hrm_cv_drop_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_job_description`
--
ALTER TABLE `hrm_cv_job_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_job_description_group`
--
ALTER TABLE `hrm_cv_job_description_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_job_requsition`
--
ALTER TABLE `hrm_cv_job_requsition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_job_requsition_compensation`
--
ALTER TABLE `hrm_cv_job_requsition_compensation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_cv_job_requsition_details`
--
ALTER TABLE `hrm_cv_job_requsition_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_days_name`
--
ALTER TABLE `hrm_days_name`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hrm_default_head`
--
ALTER TABLE `hrm_default_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hrm_deleted_data_log`
--
ALTER TABLE `hrm_deleted_data_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_depertment`
--
ALTER TABLE `hrm_depertment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `hrm_designation`
--
ALTER TABLE `hrm_designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `hrm_device_information`
--
ALTER TABLE `hrm_device_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hrm_education`
--
ALTER TABLE `hrm_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `hrm_eligible_ot_employee`
--
ALTER TABLE `hrm_eligible_ot_employee`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_eligible_ot_pending`
--
ALTER TABLE `hrm_eligible_ot_pending`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee`
--
ALTER TABLE `hrm_employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `hrm_employee_activity`
--
ALTER TABLE `hrm_employee_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `hrm_employee_bonus`
--
ALTER TABLE `hrm_employee_bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_bonus_cw`
--
ALTER TABLE `hrm_employee_bonus_cw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_bonus_master`
--
ALTER TABLE `hrm_employee_bonus_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_card_code`
--
ALTER TABLE `hrm_employee_card_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `hrm_employee_draft`
--
ALTER TABLE `hrm_employee_draft`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_file`
--
ALTER TABLE `hrm_employee_file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_holiday`
--
ALTER TABLE `hrm_employee_holiday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_holiday_details`
--
ALTER TABLE `hrm_employee_holiday_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_inactive`
--
ALTER TABLE `hrm_employee_inactive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_job_approval`
--
ALTER TABLE `hrm_employee_job_approval`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_job_info`
--
ALTER TABLE `hrm_employee_job_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `hrm_employee_job_info_draft`
--
ALTER TABLE `hrm_employee_job_info_draft`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_joining`
--
ALTER TABLE `hrm_employee_joining`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `hrm_employee_leave_type`
--
ALTER TABLE `hrm_employee_leave_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_leave_year`
--
ALTER TABLE `hrm_employee_leave_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_long_service`
--
ALTER TABLE `hrm_employee_long_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_probation`
--
ALTER TABLE `hrm_employee_probation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_resignation`
--
ALTER TABLE `hrm_employee_resignation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_salary`
--
ALTER TABLE `hrm_employee_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_salary_details`
--
ALTER TABLE `hrm_employee_salary_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_shift`
--
ALTER TABLE `hrm_employee_shift`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `hrm_employee_shift_auto`
--
ALTER TABLE `hrm_employee_shift_auto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_task`
--
ALTER TABLE `hrm_employee_task`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_task_assign`
--
ALTER TABLE `hrm_employee_task_assign`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_task_complete`
--
ALTER TABLE `hrm_employee_task_complete`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employee_task_type`
--
ALTER TABLE `hrm_employee_task_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employment_status`
--
ALTER TABLE `hrm_employment_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hrm_favourite_link`
--
ALTER TABLE `hrm_favourite_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_file_type`
--
ALTER TABLE `hrm_file_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_fringe_benefits_config`
--
ALTER TABLE `hrm_fringe_benefits_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_fringe_benefits_config_details`
--
ALTER TABLE `hrm_fringe_benefits_config_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_holiday`
--
ALTER TABLE `hrm_holiday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_holidayconvert_to_working`
--
ALTER TABLE `hrm_holidayconvert_to_working`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_holiday_against_leave`
--
ALTER TABLE `hrm_holiday_against_leave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_holiday_configure`
--
ALTER TABLE `hrm_holiday_configure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_assesment_date`
--
ALTER TABLE `hrm_kpi_assesment_date`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_assesment_year`
--
ALTER TABLE `hrm_kpi_assesment_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_deduction_mark`
--
ALTER TABLE `hrm_kpi_deduction_mark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_dept_head_assign_details`
--
ALTER TABLE `hrm_kpi_dept_head_assign_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_dept_head_assign_master`
--
ALTER TABLE `hrm_kpi_dept_head_assign_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_dynamic_table`
--
ALTER TABLE `hrm_kpi_dynamic_table`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hrm_kpi_employee_details`
--
ALTER TABLE `hrm_kpi_employee_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_employee_final_summary`
--
ALTER TABLE `hrm_kpi_employee_final_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_employee_mark_deduct`
--
ALTER TABLE `hrm_kpi_employee_mark_deduct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_employee_master`
--
ALTER TABLE `hrm_kpi_employee_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_increment_range`
--
ALTER TABLE `hrm_kpi_increment_range`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_marks`
--
ALTER TABLE `hrm_kpi_marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_set_config`
--
ALTER TABLE `hrm_kpi_set_config`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_set_config_department`
--
ALTER TABLE `hrm_kpi_set_config_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_set_config_dept_with`
--
ALTER TABLE `hrm_kpi_set_config_dept_with`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_task`
--
ALTER TABLE `hrm_kpi_task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_task_department`
--
ALTER TABLE `hrm_kpi_task_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_task_department_details`
--
ALTER TABLE `hrm_kpi_task_department_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_task_details`
--
ALTER TABLE `hrm_kpi_task_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_kpi_task_type`
--
ALTER TABLE `hrm_kpi_task_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_last_promotion`
--
ALTER TABLE `hrm_last_promotion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_leave_application`
--
ALTER TABLE `hrm_leave_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_leave_approve`
--
ALTER TABLE `hrm_leave_approve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_leave_ledger`
--
ALTER TABLE `hrm_leave_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_leave_type_year`
--
ALTER TABLE `hrm_leave_type_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_leave_years`
--
ALTER TABLE `hrm_leave_years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_loan_application`
--
ALTER TABLE `hrm_loan_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_loan_ledger`
--
ALTER TABLE `hrm_loan_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_loan_payregister_details`
--
ALTER TABLE `hrm_loan_payregister_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_loan_type`
--
ALTER TABLE `hrm_loan_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_location`
--
ALTER TABLE `hrm_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hrm_location_interval`
--
ALTER TABLE `hrm_location_interval`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_manual_ot`
--
ALTER TABLE `hrm_manual_ot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_marital_status`
--
ALTER TABLE `hrm_marital_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `hrm_month`
--
ALTER TABLE `hrm_month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `hrm_mynote`
--
ALTER TABLE `hrm_mynote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_organogram`
--
ALTER TABLE `hrm_organogram`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_ot_process_details`
--
ALTER TABLE `hrm_ot_process_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_ot_process_master`
--
ALTER TABLE `hrm_ot_process_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_ot_time`
--
ALTER TABLE `hrm_ot_time`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_plant`
--
ALTER TABLE `hrm_plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hrm_plantwise_employee`
--
ALTER TABLE `hrm_plantwise_employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_plant_details`
--
ALTER TABLE `hrm_plant_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_plant_with_section`
--
ALTER TABLE `hrm_plant_with_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_probation_period`
--
ALTER TABLE `hrm_probation_period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `hrm_redflag`
--
ALTER TABLE `hrm_redflag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_religion`
--
ALTER TABLE `hrm_religion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `hrm_salary_deduction`
--
ALTER TABLE `hrm_salary_deduction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_extra_feature`
--
ALTER TABLE `hrm_salary_extra_feature`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_extra_feature_details`
--
ALTER TABLE `hrm_salary_extra_feature_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_generate_master`
--
ALTER TABLE `hrm_salary_generate_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_grade`
--
ALTER TABLE `hrm_salary_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hrm_salary_grade_details`
--
ALTER TABLE `hrm_salary_grade_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `hrm_salary_grade_master`
--
ALTER TABLE `hrm_salary_grade_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hrm_salary_head`
--
ALTER TABLE `hrm_salary_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `hrm_salary_head_group`
--
ALTER TABLE `hrm_salary_head_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `hrm_salary_increment`
--
ALTER TABLE `hrm_salary_increment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_increment_details`
--
ALTER TABLE `hrm_salary_increment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_slap`
--
ALTER TABLE `hrm_salary_slap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_section`
--
ALTER TABLE `hrm_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `hrm_set_default_head`
--
ALTER TABLE `hrm_set_default_head`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hrm_set_pf_confiq`
--
ALTER TABLE `hrm_set_pf_confiq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hrm_shift`
--
ALTER TABLE `hrm_shift`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '0 for general\n1 for shifting', AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `hrm_shift_role`
--
ALTER TABLE `hrm_shift_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_shift_role_duration`
--
ALTER TABLE `hrm_shift_role_duration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_shift_role_employee`
--
ALTER TABLE `hrm_shift_role_employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_skill`
--
ALTER TABLE `hrm_skill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_skill_employeewise`
--
ALTER TABLE `hrm_skill_employeewise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log_ot`
--
ALTER TABLE `log_ot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mobile_log`
--
ALTER TABLE `mobile_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `module_info`
--
ALTER TABLE `module_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_register`
--
ALTER TABLE `pay_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_register_cw`
--
ALTER TABLE `pay_register_cw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_register_cw_ot`
--
ALTER TABLE `pay_register_cw_ot`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_register_details`
--
ALTER TABLE `pay_register_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `permission_module`
--
ALTER TABLE `permission_module`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tmp_hrm_attendance_data`
--
ALTER TABLE `tmp_hrm_attendance_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_location`
--
ALTER TABLE `user_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assigned_roles`
--
ALTER TABLE `assigned_roles`
  ADD CONSTRAINT `fk_assigned_roles_roles1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_assigned_roles_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_exchange_emp`
--
ALTER TABLE `hrm_acc_exchange_emp`
  ADD CONSTRAINT `fk_hrm_acc_exchange_emp_hrm_acc_head_title1` FOREIGN KEY (`hrm_acc_head_title_id`) REFERENCES `hrm_acc_head_title` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_acc_exchange_emp_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_acc_exchange_emp_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_headwise_emp_tag`
--
ALTER TABLE `hrm_acc_headwise_emp_tag`
  ADD CONSTRAINT `fk_hrm_acc_headwise_emp_tag_hrm_acc_head_title1` FOREIGN KEY (`hrm_acc_head_title_id`) REFERENCES `hrm_acc_head_title` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_headwise_emp_tag_category`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_category`
  ADD CONSTRAINT `fk_hrm_acc_headwise_emp_tag_category_hrm_acc_headwise_emp_tag1` FOREIGN KEY (`hrm_acc_headwise_emp_tag_id`) REFERENCES `hrm_acc_headwise_emp_tag` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_acc_headwise_emp_tag_category_hrm_category1` FOREIGN KEY (`hrm_category_id`) REFERENCES `hrm_category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_headwise_emp_tag_location`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_location`
  ADD CONSTRAINT `fk_hrm_acc_headwise_emp_tag_details_hrm_acc_headwise_emp_tag1` FOREIGN KEY (`hrm_acc_headwise_emp_tag_id`) REFERENCES `hrm_acc_headwise_emp_tag` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_headwise_emp_tag_salaryhead`
--
ALTER TABLE `hrm_acc_headwise_emp_tag_salaryhead`
  ADD CONSTRAINT `fk_hrm_acc_headwise_emp_tag_salaryhead_hrm_acc_headwise_emp_t1` FOREIGN KEY (`hrm_acc_headwise_emp_tag_id`) REFERENCES `hrm_acc_headwise_emp_tag` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_acc_headwise_emp_tag_salaryhead_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_head_integration`
--
ALTER TABLE `hrm_acc_head_integration`
  ADD CONSTRAINT `fk_hrm_acc_head_integration_hrm_acc_head_title1` FOREIGN KEY (`hrm_acc_head_title_id`) REFERENCES `hrm_acc_head_title` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_acc_head_integration_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_acc_head_title`
--
ALTER TABLE `hrm_acc_head_title`
  ADD CONSTRAINT `fk_hrm_acc_head_title_hrm_acc_journal_type1` FOREIGN KEY (`hrm_acc_journal_type_id`) REFERENCES `hrm_acc_journal_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_acc_head_title_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset`
--
ALTER TABLE `hrm_asset`
  ADD CONSTRAINT `fk_hrm_asset_hrm_asset_brand1` FOREIGN KEY (`brand_id`) REFERENCES `hrm_asset_brand` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_hrm_asset_type1` FOREIGN KEY (`asset_type_id`) REFERENCES `hrm_asset_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_assign_ledger`
--
ALTER TABLE `hrm_asset_assign_ledger`
  ADD CONSTRAINT `fk_hrm_asset_assign_ledger_hrm_asset1` FOREIGN KEY (`product_id`) REFERENCES `hrm_asset` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_assign_ledger_hrm_asset_assign_master1` FOREIGN KEY (`asset_assign_master_id`) REFERENCES `hrm_asset_assign_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_assign_master`
--
ALTER TABLE `hrm_asset_assign_master`
  ADD CONSTRAINT `fk_hrm_asset_assign_master_hrm_asset_store_master1` FOREIGN KEY (`hrm_asset_store_master_id`) REFERENCES `hrm_asset_store_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_assign_master_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_assign_master_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_assign_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_brand`
--
ALTER TABLE `hrm_asset_brand`
  ADD CONSTRAINT `fk_hrm_asset_brand_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_purchase_ledger`
--
ALTER TABLE `hrm_asset_purchase_ledger`
  ADD CONSTRAINT `fk_hrm_asset_purchase_ledger_hrm_asset1` FOREIGN KEY (`product_id`) REFERENCES `hrm_asset` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_purchase_ledger_hrm_asset_purchase_master1` FOREIGN KEY (`asset_purchase_master_id`) REFERENCES `hrm_asset_purchase_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_purchase_master`
--
ALTER TABLE `hrm_asset_purchase_master`
  ADD CONSTRAINT `fk_hrm_asset_purchase_master_hrm_asset_store_master1` FOREIGN KEY (`asset_store_master_id`) REFERENCES `hrm_asset_store_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_purchase_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_return_master`
--
ALTER TABLE `hrm_asset_return_master`
  ADD CONSTRAINT `fk_hrm_asset_return_master_hrm_asset_assign_master1` FOREIGN KEY (`hrm_asset_assign_master_id`) REFERENCES `hrm_asset_assign_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_return_master_hrm_asset_return_type1` FOREIGN KEY (`hrm_asset_return_type_id`) REFERENCES `hrm_asset_return_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_return_master_hrm_asset_store_master1` FOREIGN KEY (`hrm_asset_store_master_id`) REFERENCES `hrm_asset_store_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_return_type`
--
ALTER TABLE `hrm_asset_return_type`
  ADD CONSTRAINT `fk_hrm_asset_return_type_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_store_ledger`
--
ALTER TABLE `hrm_asset_store_ledger`
  ADD CONSTRAINT `fk_hrm_asset_store_ledger_hrm_asset1` FOREIGN KEY (`product_id`) REFERENCES `hrm_asset` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_asset_store_ledger_hrm_asset_store_master1` FOREIGN KEY (`asset_store_master_id`) REFERENCES `hrm_asset_store_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_store_master`
--
ALTER TABLE `hrm_asset_store_master`
  ADD CONSTRAINT `fk_hrm_asset_store_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_asset_type`
--
ALTER TABLE `hrm_asset_type`
  ADD CONSTRAINT `fk_hrm_asset_type_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_attendance`
--
ALTER TABLE `hrm_attendance`
  ADD CONSTRAINT `fk_hrm_attendance_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_attendance_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_attendance_hrm_shift1` FOREIGN KEY (`hrm_shift_id`) REFERENCES `hrm_shift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_attendance_data`
--
ALTER TABLE `hrm_attendance_data`
  ADD CONSTRAINT `fk_hrm_attendance_data_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_attendance_data_hrm_shift1` FOREIGN KEY (`hrm_shift_id`) REFERENCES `hrm_shift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_attendance_data_process_log`
--
ALTER TABLE `hrm_attendance_data_process_log`
  ADD CONSTRAINT `fk_hrm_attendance_process_log_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_attendance_process_user_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_attendance_raw_data`
--
ALTER TABLE `hrm_attendance_raw_data`
  ADD CONSTRAINT `fk_hrm_attendance_raw_data_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_attendance_raw_data_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_category`
--
ALTER TABLE `hrm_category`
  ADD CONSTRAINT `fk_hrm_category_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_change_employee_shift`
--
ALTER TABLE `hrm_change_employee_shift`
  ADD CONSTRAINT `fk_hrm_change_employee_shift_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_change_employee_shift_hrm_shift1` FOREIGN KEY (`hrm_shift_id`) REFERENCES `hrm_shift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_custom_filter_details`
--
ALTER TABLE `hrm_custom_filter_details`
  ADD CONSTRAINT `fk_hrm_custom_filter_details_hrm_custom_filter_master1` FOREIGN KEY (`hrm_custom_filter_master_id`) REFERENCES `hrm_custom_filter_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_custom_filter_master`
--
ALTER TABLE `hrm_custom_filter_master`
  ADD CONSTRAINT `fk_hrm_custom_filter_master_hrm_custom_filter1` FOREIGN KEY (`hrm_custom_filter_id`) REFERENCES `hrm_custom_filter` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_custom_filter_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_compensation`
--
ALTER TABLE `hrm_cv_compensation`
  ADD CONSTRAINT `fk_hrm_cv_compensation_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_drop_details`
--
ALTER TABLE `hrm_cv_drop_details`
  ADD CONSTRAINT `fk_hrm_cv_drop_details_hrm_cv_drop_master1` FOREIGN KEY (`hrm_cv_drop_master_id`) REFERENCES `hrm_cv_drop_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_drop_details_hrm_cv_job_requsition_details1` FOREIGN KEY (`hrm_cv_job_requsition_details_id`) REFERENCES `hrm_cv_job_requsition_details` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_drop_master`
--
ALTER TABLE `hrm_cv_drop_master`
  ADD CONSTRAINT `fk_hrm_cv_drop_master_hrm_cv_job_requsition1` FOREIGN KEY (`hrm_cv_job_requsition_id`) REFERENCES `hrm_cv_job_requsition` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_job_description`
--
ALTER TABLE `hrm_cv_job_description`
  ADD CONSTRAINT `fk_hrm_cv_job_description_hrm_cv_job_description_group1` FOREIGN KEY (`hrm_cv_job_description_group_id`) REFERENCES `hrm_cv_job_description_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_description_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_description_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_job_requsition`
--
ALTER TABLE `hrm_cv_job_requsition`
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_hrm_designation1` FOREIGN KEY (`hrm_designation_id`) REFERENCES `hrm_designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_users2` FOREIGN KEY (`approved_by_users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_job_requsition_compensation`
--
ALTER TABLE `hrm_cv_job_requsition_compensation`
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_compensation_hrm_cv_compensation1` FOREIGN KEY (`hrm_cv_compensation_id`) REFERENCES `hrm_cv_compensation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_compensation_hrm_cv_job_requsition1` FOREIGN KEY (`hrm_cv_job_requsition_id`) REFERENCES `hrm_cv_job_requsition` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_cv_job_requsition_details`
--
ALTER TABLE `hrm_cv_job_requsition_details`
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_details_hrm_cv_job_description1` FOREIGN KEY (`hrm_cv_job_description_id`) REFERENCES `hrm_cv_job_description` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_cv_job_requsition_details_hrm_cv_job_requsition1` FOREIGN KEY (`hrm_cv_job_requsition_id`) REFERENCES `hrm_cv_job_requsition` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_deleted_data_log`
--
ALTER TABLE `hrm_deleted_data_log`
  ADD CONSTRAINT `fk_hrm_deleted_data_log_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_depertment`
--
ALTER TABLE `hrm_depertment`
  ADD CONSTRAINT `fk_hrm_depertment_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_designation`
--
ALTER TABLE `hrm_designation`
  ADD CONSTRAINT `fk_hrm_designation_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee`
--
ALTER TABLE `hrm_employee`
  ADD CONSTRAINT `fk_hrm_employee_hrm_blood_group1` FOREIGN KEY (`hrm_blood_group_id`) REFERENCES `hrm_blood_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_hrm_education1` FOREIGN KEY (`hrm_education_id`) REFERENCES `hrm_education` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_hrm_marital_status1` FOREIGN KEY (`hrm_marital_status_id`) REFERENCES `hrm_marital_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_hrm_religion1` FOREIGN KEY (`hrm_religion_id`) REFERENCES `hrm_religion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_activity`
--
ALTER TABLE `hrm_employee_activity`
  ADD CONSTRAINT `fk_employee_activity_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_employee_activity_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_activity_hrm_employee_activity_status1` FOREIGN KEY (`hrm_employee_activity_status_id`) REFERENCES `hrm_employee_activity_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_bonus`
--
ALTER TABLE `hrm_employee_bonus`
  ADD CONSTRAINT `fk_hrm_employee_bonus_hrm_bonus1` FOREIGN KEY (`hrm_bonus_id`) REFERENCES `hrm_bonus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_bonus_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_bonus_cw`
--
ALTER TABLE `hrm_employee_bonus_cw`
  ADD CONSTRAINT `fk_hrm_employee_bonus_cw_hrm_employee_bonus_master1` FOREIGN KEY (`hrm_employee_bonus_master_id`) REFERENCES `hrm_employee_bonus_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_bonus_master`
--
ALTER TABLE `hrm_employee_bonus_master`
  ADD CONSTRAINT `fk_hrm_employee_bonus_master_hrm_bonus1` FOREIGN KEY (`hrm_bonus_id`) REFERENCES `hrm_bonus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_bonus_master_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_bonus_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_card_code`
--
ALTER TABLE `hrm_employee_card_code`
  ADD CONSTRAINT `fk_hrm_employee_card_code_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_card_code_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_file`
--
ALTER TABLE `hrm_employee_file`
  ADD CONSTRAINT `fk_hrm_employee_file_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_file_hrm_file_type1` FOREIGN KEY (`hrm_file_type_id`) REFERENCES `hrm_file_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_holiday`
--
ALTER TABLE `hrm_employee_holiday`
  ADD CONSTRAINT `fk_hrm_employee_holiday_hrm_holiday1` FOREIGN KEY (`hrm_holiday_id`) REFERENCES `hrm_holiday` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_holiday_hrm_leave_years1` FOREIGN KEY (`hrm_leave_years_id`) REFERENCES `hrm_leave_years` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_holiday_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_holiday_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_holiday_details`
--
ALTER TABLE `hrm_employee_holiday_details`
  ADD CONSTRAINT `fk_hrm_employee_holiday_details_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_holiday_details_hrm_employee_holiday1` FOREIGN KEY (`hrm_employee_holiday_id`) REFERENCES `hrm_employee_holiday` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_inactive`
--
ALTER TABLE `hrm_employee_inactive`
  ADD CONSTRAINT `fk_hrm_inactive_employee_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_inactive_employee_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_job_approval`
--
ALTER TABLE `hrm_employee_job_approval`
  ADD CONSTRAINT `fk_hrm_employee_job_approval_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_approval_users1` FOREIGN KEY (`job_users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_approval_users2` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_job_info`
--
ALTER TABLE `hrm_employee_job_info`
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_category1` FOREIGN KEY (`hrm_category_id`) REFERENCES `hrm_category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_designation1` FOREIGN KEY (`hrm_designation_id`) REFERENCES `hrm_designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_employee2` FOREIGN KEY (`hrm_manage_by_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_employment_status1` FOREIGN KEY (`hrm_employment_status_id`) REFERENCES `hrm_employment_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_hrm_section1` FOREIGN KEY (`hrm_section_id`) REFERENCES `hrm_section` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_job_info_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_joining`
--
ALTER TABLE `hrm_employee_joining`
  ADD CONSTRAINT `fk_hrm_employee_joining_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_leave_year`
--
ALTER TABLE `hrm_employee_leave_year`
  ADD CONSTRAINT `fk_hrm_employee_leave_year_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_leave_year_hrm_leave_years1` FOREIGN KEY (`hrm_leave_years_id`) REFERENCES `hrm_leave_years` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_leave_year_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_long_service`
--
ALTER TABLE `hrm_employee_long_service`
  ADD CONSTRAINT `fk_hrm_employee_long_service_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_long_service_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_probation`
--
ALTER TABLE `hrm_employee_probation`
  ADD CONSTRAINT `fk_hrm_employee_probation_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_probation_hrm_probation_period1` FOREIGN KEY (`hrm_probation_period_id`) REFERENCES `hrm_probation_period` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_probation_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_resignation`
--
ALTER TABLE `hrm_employee_resignation`
  ADD CONSTRAINT `fk_hrm_employee_resignation_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_resignation_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_salary`
--
ALTER TABLE `hrm_employee_salary`
  ADD CONSTRAINT `fk_hrm_employee_salary_hrm_bank1` FOREIGN KEY (`hrm_bank_id`) REFERENCES `hrm_bank` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_salary_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_salary_hrm_salary_grade_master1` FOREIGN KEY (`hrm_salary_grade_master_id`) REFERENCES `hrm_salary_grade_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_salary_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_salary_details`
--
ALTER TABLE `hrm_employee_salary_details`
  ADD CONSTRAINT `fk_hrm_employee_salary_details_hrm_employee_salary1` FOREIGN KEY (`hrm_employee_salary_id`) REFERENCES `hrm_employee_salary` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_salary_details_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_shift`
--
ALTER TABLE `hrm_employee_shift`
  ADD CONSTRAINT `fk_hrm_employee_shift_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_shift_hrm_shift1` FOREIGN KEY (`hrm_shift_id`) REFERENCES `hrm_shift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_task`
--
ALTER TABLE `hrm_employee_task`
  ADD CONSTRAINT `fk_hrm_employee_task_hrm_employee_task_type1` FOREIGN KEY (`hrm_employee_task_type_id`) REFERENCES `hrm_employee_task_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_task_assign`
--
ALTER TABLE `hrm_employee_task_assign`
  ADD CONSTRAINT `fk_hrm_employee_task_assign_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_employee_task_assign_hrm_employee_task1` FOREIGN KEY (`hrm_employee_task_id`) REFERENCES `hrm_employee_task` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_employee_task_complete`
--
ALTER TABLE `hrm_employee_task_complete`
  ADD CONSTRAINT `fk_hrm_employee_task_complete_hrm_employee_task_assign1` FOREIGN KEY (`hrm_employee_task_assign_id`) REFERENCES `hrm_employee_task_assign` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_favourite_link`
--
ALTER TABLE `hrm_favourite_link`
  ADD CONSTRAINT `fk_hrm_favourite_link_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_fringe_benefits_config`
--
ALTER TABLE `hrm_fringe_benefits_config`
  ADD CONSTRAINT `fk_fringe_benefits_config_hrm_designation1` FOREIGN KEY (`hrm_designation_id`) REFERENCES `hrm_designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_fringe_benefits_config_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_fringe_benefits_config_details`
--
ALTER TABLE `hrm_fringe_benefits_config_details`
  ADD CONSTRAINT `fk_fringe_benefits_config_details_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_fringe_benefits_config_details_hrm_fringe_benefits_con1` FOREIGN KEY (`hrm_fringe_benefits_config_id`) REFERENCES `hrm_fringe_benefits_config` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_holidayconvert_to_working`
--
ALTER TABLE `hrm_holidayconvert_to_working`
  ADD CONSTRAINT `fk_hrm_holidayconvert_to_working_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_holidayconvert_to_working_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_holiday_against_leave`
--
ALTER TABLE `hrm_holiday_against_leave`
  ADD CONSTRAINT `fk_hrm_holiday_agents_leave_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_holiday_agents_leave_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_holiday_configure`
--
ALTER TABLE `hrm_holiday_configure`
  ADD CONSTRAINT `fk_hrm_holiday_configure_hrm_days_name1` FOREIGN KEY (`hrm_days_name_id`) REFERENCES `hrm_days_name` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_holiday_configure_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_holiday_configure_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_holiday_configure_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_assesment_date`
--
ALTER TABLE `hrm_kpi_assesment_date`
  ADD CONSTRAINT `fk_hrm_kpi_assesment_date_hrm_kpi_assesment_year1` FOREIGN KEY (`hrm_kpi_assesment_year_id`) REFERENCES `hrm_kpi_assesment_year` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_assesment_date_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_assesment_year`
--
ALTER TABLE `hrm_kpi_assesment_year`
  ADD CONSTRAINT `fk_hrm_kpi_assesment_year_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_deduction_mark`
--
ALTER TABLE `hrm_kpi_deduction_mark`
  ADD CONSTRAINT `fk_hrm_kpi_deduction_mark_hrm_file_type1` FOREIGN KEY (`hrm_file_type_id`) REFERENCES `hrm_file_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_deduction_mark_hrm_kpi_assesment_date1` FOREIGN KEY (`hrm_kpi_assesment_date_id`) REFERENCES `hrm_kpi_assesment_date` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_deduction_mark_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_dept_head_assign_details`
--
ALTER TABLE `hrm_kpi_dept_head_assign_details`
  ADD CONSTRAINT `fk_hrm_kpi_dept_head_assign_details_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_dept_head_assign_details_hrm_kpi_dept_head_assign_1` FOREIGN KEY (`hrm_kpi_dept_head_assign_master_id`) REFERENCES `hrm_kpi_dept_head_assign_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_dept_head_assign_master`
--
ALTER TABLE `hrm_kpi_dept_head_assign_master`
  ADD CONSTRAINT `fk_hrm_kpi_dept_head_assign_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_dept_head_assign_hrm_kpi_assesment_date1` FOREIGN KEY (`hrm_kpi_assesment_date_id`) REFERENCES `hrm_kpi_assesment_date` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_dept_head_assign_master_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_dept_head_assign_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_employee_details`
--
ALTER TABLE `hrm_kpi_employee_details`
  ADD CONSTRAINT `fk_hrm_kpi_employee_details_hrm_kpi_employee_master1` FOREIGN KEY (`hrm_kpi_employee_master_id`) REFERENCES `hrm_kpi_employee_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_employee_details_hrm_kpi_marks1` FOREIGN KEY (`hrm_kpi_marks_id`) REFERENCES `hrm_kpi_marks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_employee_details_hrm_kpi_task_details1` FOREIGN KEY (`hrm_kpi_task_details_id`) REFERENCES `hrm_kpi_task_details` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_employee_final_summary`
--
ALTER TABLE `hrm_kpi_employee_final_summary`
  ADD CONSTRAINT `fk_hrm_kpi_employee_final_summary_hrm_kpi_employee_master1` FOREIGN KEY (`hrm_kpi_employee_master_id`) REFERENCES `hrm_kpi_employee_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_employee_final_summary_hrm_kpi_increment_range1` FOREIGN KEY (`hrm_kpi_increment_range_id`) REFERENCES `hrm_kpi_increment_range` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_employee_final_summary_hrm_kpi_increment_range2` FOREIGN KEY (`hrm_kpi_promotion_range_id`) REFERENCES `hrm_kpi_increment_range` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_employee_mark_deduct`
--
ALTER TABLE `hrm_kpi_employee_mark_deduct`
  ADD CONSTRAINT `fk_hrm_kpi_employee_mark_deduct_hrm_file_type1` FOREIGN KEY (`hrm_file_type_id`) REFERENCES `hrm_file_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_employee_mark_deduct_hrm_kpi_employee_master1` FOREIGN KEY (`hrm_kpi_employee_master_id`) REFERENCES `hrm_kpi_employee_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_employee_master`
--
ALTER TABLE `hrm_kpi_employee_master`
  ADD CONSTRAINT `fk_hrm_employee_kpi_hrm_kpi_assesment_date1` FOREIGN KEY (`hrm_kpi_assesment_date_id`) REFERENCES `hrm_kpi_assesment_date` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_employee_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_increment_range`
--
ALTER TABLE `hrm_kpi_increment_range`
  ADD CONSTRAINT `fk_hrm_kpi_increment_range_hrm_kpi_assesment_date1` FOREIGN KEY (`hrm_kpi_assesment_date_id`) REFERENCES `hrm_kpi_assesment_date` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_increment_range_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_marks`
--
ALTER TABLE `hrm_kpi_marks`
  ADD CONSTRAINT `fk_hrm_kpi_marks_hrm_kpi_set_config1` FOREIGN KEY (`hrm_kpi_set_config_id`) REFERENCES `hrm_kpi_set_config` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_marks_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_set_config`
--
ALTER TABLE `hrm_kpi_set_config`
  ADD CONSTRAINT `fk_hrm_kpi_config_hrm_kpi_assesment_date1` FOREIGN KEY (`hrm_kpi_assesment_date_id`) REFERENCES `hrm_kpi_assesment_date` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_set_config_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_set_config_department`
--
ALTER TABLE `hrm_kpi_set_config_department`
  ADD CONSTRAINT `fk_hrm_kpi_config_department_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_config_department_hrm_kpi_set_config1` FOREIGN KEY (`hrm_kpi_set_config_id`) REFERENCES `hrm_kpi_set_config` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_set_config_department_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_set_config_dept_with`
--
ALTER TABLE `hrm_kpi_set_config_dept_with`
  ADD CONSTRAINT `fk_hrm_kpi_set_config_dept_with_hrm_kpi_set_config_department1` FOREIGN KEY (`hrm_kpi_set_config_department_id`) REFERENCES `hrm_kpi_set_config_department` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_set_config_dept_with_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_task`
--
ALTER TABLE `hrm_kpi_task`
  ADD CONSTRAINT `fk_hrm_kpi_task_hrm_kpi_task_type1` FOREIGN KEY (`hrm_kpi_task_type_id`) REFERENCES `hrm_kpi_task_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_task_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_task_department`
--
ALTER TABLE `hrm_kpi_task_department`
  ADD CONSTRAINT `fk_hrm_task_department_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_task_department_details`
--
ALTER TABLE `hrm_kpi_task_department_details`
  ADD CONSTRAINT `fk_hrm_kpi_task_department_details_hrm_kpi_task_department1` FOREIGN KEY (`hrm_kpi_task_department_id`) REFERENCES `hrm_kpi_task_department` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_task_department_details_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_task_details`
--
ALTER TABLE `hrm_kpi_task_details`
  ADD CONSTRAINT `fk_hrm_kpi_task_details_hrm_kpi_set_config1` FOREIGN KEY (`hrm_kpi_set_config_id`) REFERENCES `hrm_kpi_set_config` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_task_details_hrm_kpi_task1` FOREIGN KEY (`hrm_kpi_task_id`) REFERENCES `hrm_kpi_task` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_task_details_hrm_kpi_task_department1` FOREIGN KEY (`hrm_kpi_task_department_id`) REFERENCES `hrm_kpi_task_department` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_kpi_task_details_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_kpi_task_type`
--
ALTER TABLE `hrm_kpi_task_type`
  ADD CONSTRAINT `fk_hrm_kpi_task_type_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_last_promotion`
--
ALTER TABLE `hrm_last_promotion`
  ADD CONSTRAINT `fk_hrm_last_promotion_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_last_promotion_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_leave_application`
--
ALTER TABLE `hrm_leave_application`
  ADD CONSTRAINT `fk_hrm_leave_application_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_application_hrm_employee_leave_type1` FOREIGN KEY (`hrm_employee_leave_type_id`) REFERENCES `hrm_employee_leave_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_application_hrm_leave_years1` FOREIGN KEY (`hrm_leave_years_id`) REFERENCES `hrm_leave_years` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_leave_approve`
--
ALTER TABLE `hrm_leave_approve`
  ADD CONSTRAINT `fk_hrm_leave_approve_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_approve_hrm_leave_application1` FOREIGN KEY (`hrm_leave_application_id`) REFERENCES `hrm_leave_application` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_approve_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_leave_ledger`
--
ALTER TABLE `hrm_leave_ledger`
  ADD CONSTRAINT `fk_hrm_leave_ledger_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_ledger_hrm_employee_leave_type1` FOREIGN KEY (`hrm_employee_leave_type_id`) REFERENCES `hrm_employee_leave_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_ledger_hrm_leave_approve1` FOREIGN KEY (`hrm_leave_approve_id`) REFERENCES `hrm_leave_approve` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_ledger_hrm_leave_years1` FOREIGN KEY (`hrm_leave_years_id`) REFERENCES `hrm_leave_years` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_ledger_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_leave_type_year`
--
ALTER TABLE `hrm_leave_type_year`
  ADD CONSTRAINT `fk_hrm_leave_type_year_hrm_employee_leave_type1` FOREIGN KEY (`hrm_employee_leave_type_id`) REFERENCES `hrm_employee_leave_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_leave_type_year_hrm_leave_years1` FOREIGN KEY (`hrm_leave_years_id`) REFERENCES `hrm_leave_years` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_loan_application`
--
ALTER TABLE `hrm_loan_application`
  ADD CONSTRAINT `fk_hrm_loan_application_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_loan_application_hrm_loan_type1` FOREIGN KEY (`hrm_loan_type_id`) REFERENCES `hrm_loan_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_loan_application_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_loan_ledger`
--
ALTER TABLE `hrm_loan_ledger`
  ADD CONSTRAINT `fk_hrm_loan_ledger_hrm_loan_application1` FOREIGN KEY (`hrm_loan_application_id`) REFERENCES `hrm_loan_application` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_loan_ledger_hrm_month1` FOREIGN KEY (`hrm_month_id`) REFERENCES `hrm_month` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_loan_ledger_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_loan_payregister_details`
--
ALTER TABLE `hrm_loan_payregister_details`
  ADD CONSTRAINT `fk_hrm_loan_payregister_details_hrm_loan_application1` FOREIGN KEY (`hrm_loan_application_id`) REFERENCES `hrm_loan_application` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_loan_payregister_details_pay_register_details1` FOREIGN KEY (`pay_register_details_id`) REFERENCES `pay_register_details` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_loan_type`
--
ALTER TABLE `hrm_loan_type`
  ADD CONSTRAINT `fk_hrm_loan_type_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_loan_type_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_location`
--
ALTER TABLE `hrm_location`
  ADD CONSTRAINT `fk_hrm_location_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_location_interval`
--
ALTER TABLE `hrm_location_interval`
  ADD CONSTRAINT `fk_hrm_location_interval_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_manual_ot`
--
ALTER TABLE `hrm_manual_ot`
  ADD CONSTRAINT `fk_hrm_manual_ot_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_manual_ot_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_manual_ot_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_mynote`
--
ALTER TABLE `hrm_mynote`
  ADD CONSTRAINT `fk_hrm_mynote_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_organogram`
--
ALTER TABLE `hrm_organogram`
  ADD CONSTRAINT `fk_hrm_organogram_hrm_depertment1` FOREIGN KEY (`hrm_depertment_id`) REFERENCES `hrm_depertment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_organogram_hrm_designation` FOREIGN KEY (`hrm_designation_id`) REFERENCES `hrm_designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_organogram_hrm_designation1` FOREIGN KEY (`hrm_parent_id`) REFERENCES `hrm_designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_ot_process_details`
--
ALTER TABLE `hrm_ot_process_details`
  ADD CONSTRAINT `fk_hrm_ot_process_details_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_ot_process_details_hrm_ot_process_master1` FOREIGN KEY (`hrm_ot_process_master_id`) REFERENCES `hrm_ot_process_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_ot_process_master`
--
ALTER TABLE `hrm_ot_process_master`
  ADD CONSTRAINT `fk_hrm_ot_process_master_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_ot_process_master_hrm_month1` FOREIGN KEY (`hrm_month_id`) REFERENCES `hrm_month` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_ot_process_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_ot_time`
--
ALTER TABLE `hrm_ot_time`
  ADD CONSTRAINT `fk_hrm_ot_time_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_ot_time_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_plantwise_employee`
--
ALTER TABLE `hrm_plantwise_employee`
  ADD CONSTRAINT `fk_hrm_plantwise_employee_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plantwise_employee_hrm_plant1` FOREIGN KEY (`hrm_plant_id`) REFERENCES `hrm_plant` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plantwise_employee_hrm_plant_with_section1` FOREIGN KEY (`hrm_plant_with_section_id`) REFERENCES `hrm_plant_with_section` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_plant_details`
--
ALTER TABLE `hrm_plant_details`
  ADD CONSTRAINT `fk_hrm_plant_details_hrm_month1` FOREIGN KEY (`hrm_month_id`) REFERENCES `hrm_month` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plant_details_hrm_plant1` FOREIGN KEY (`hrm_plant_id`) REFERENCES `hrm_plant` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plant_details_hrm_plant_with_section1` FOREIGN KEY (`hrm_plant_with_section_id`) REFERENCES `hrm_plant_with_section` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plant_details_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_plant_with_section`
--
ALTER TABLE `hrm_plant_with_section`
  ADD CONSTRAINT `fk_hrm_plant_with_section_hrm_plant1` FOREIGN KEY (`hrm_plant_id`) REFERENCES `hrm_plant` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plant_with_section_hrm_section1` FOREIGN KEY (`hrm_section_id`) REFERENCES `hrm_section` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_plant_with_section_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_redflag`
--
ALTER TABLE `hrm_redflag`
  ADD CONSTRAINT `fk_hrm_redflag_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_redflag_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_deduction`
--
ALTER TABLE `hrm_salary_deduction`
  ADD CONSTRAINT `fk_hrm_salary_deduction_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_deduction_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_extra_feature`
--
ALTER TABLE `hrm_salary_extra_feature`
  ADD CONSTRAINT `fk_hrm_salary_extra_feature_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_extra_feature_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_extra_feature_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_extra_feature_details`
--
ALTER TABLE `hrm_salary_extra_feature_details`
  ADD CONSTRAINT `fk_hrm_salary_extra_feature_details_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_extra_feature_details_hrm_salary_extra_feature1` FOREIGN KEY (`hrm_salary_extra_feature_id`) REFERENCES `hrm_salary_extra_feature` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_generate_master`
--
ALTER TABLE `hrm_salary_generate_master`
  ADD CONSTRAINT `fk_hrm_salary_generate_master_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_generate_master_hrm_month1` FOREIGN KEY (`hrm_month_id`) REFERENCES `hrm_month` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_generate_master_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_grade_details`
--
ALTER TABLE `hrm_salary_grade_details`
  ADD CONSTRAINT `fk_hrm_salary_grade_details_hrm_salary_grade_master1` FOREIGN KEY (`hrm_salary_grade_master_id`) REFERENCES `hrm_salary_grade_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_grade_details_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_grade_master`
--
ALTER TABLE `hrm_salary_grade_master`
  ADD CONSTRAINT `fk_hrm_salary_grade_master_hrm_salary_grade1` FOREIGN KEY (`hrm_salary_grade_id`) REFERENCES `hrm_salary_grade` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_head`
--
ALTER TABLE `hrm_salary_head`
  ADD CONSTRAINT `fk_hrm_salary_head_hrm_salary_Head_group1` FOREIGN KEY (`hrm_salary_head_group_id`) REFERENCES `hrm_salary_head_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_head_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_increment`
--
ALTER TABLE `hrm_salary_increment`
  ADD CONSTRAINT `fk_hrm_salary_increment_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_increment_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_increment_details`
--
ALTER TABLE `hrm_salary_increment_details`
  ADD CONSTRAINT `fk_hrm_salary_increment_details_hrm_designation1` FOREIGN KEY (`hrm_designation_id`) REFERENCES `hrm_designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_increment_details_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_increment_details_hrm_salary_increment1` FOREIGN KEY (`hrm_salary_increment_id`) REFERENCES `hrm_salary_increment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_salary_slap`
--
ALTER TABLE `hrm_salary_slap`
  ADD CONSTRAINT `fk_hrm_salary_slap_hrm_month1` FOREIGN KEY (`hrm_month_id`) REFERENCES `hrm_month` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_salary_slap_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_set_default_head`
--
ALTER TABLE `hrm_set_default_head`
  ADD CONSTRAINT `fk_hrm_set_default_head_hrm_default_head1` FOREIGN KEY (`hrm_default_head_id`) REFERENCES `hrm_default_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_set_default_head_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_set_default_head_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_set_pf_confiq`
--
ALTER TABLE `hrm_set_pf_confiq`
  ADD CONSTRAINT `fk_hrm_set_pf_confiq_hrm_default_head1` FOREIGN KEY (`hrm_default_head_id_own`) REFERENCES `hrm_default_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_set_pf_confiq_hrm_default_head2` FOREIGN KEY (`hrm_default_head_id_company`) REFERENCES `hrm_default_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_set_pf_confiq_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_shift`
--
ALTER TABLE `hrm_shift`
  ADD CONSTRAINT `fk_hrm_shift_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_shift_role`
--
ALTER TABLE `hrm_shift_role`
  ADD CONSTRAINT `fk_hrm_shift_role_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_shift_role_duration`
--
ALTER TABLE `hrm_shift_role_duration`
  ADD CONSTRAINT `fk_hrm_shift_role_duration_hrm_shift1` FOREIGN KEY (`hrm_shift_id`) REFERENCES `hrm_shift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_shift_role_duration_hrm_shift_role1` FOREIGN KEY (`hrm_shift_role_id`) REFERENCES `hrm_shift_role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_shift_role_employee`
--
ALTER TABLE `hrm_shift_role_employee`
  ADD CONSTRAINT `fk_hrm_shift_role_employee_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_shift_role_employee_hrm_shift_role1` FOREIGN KEY (`hrm_shift_role_id`) REFERENCES `hrm_shift_role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_skill`
--
ALTER TABLE `hrm_skill`
  ADD CONSTRAINT `fk_hrm_skill_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hrm_skill_employeewise`
--
ALTER TABLE `hrm_skill_employeewise`
  ADD CONSTRAINT `fk_hrm_skill_employeewise_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_skill_employeewise_hrm_skill1` FOREIGN KEY (`hrm_skill_id`) REFERENCES `hrm_skill` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hrm_skill_employeewise_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `fk_log_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_log_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `log_ot`
--
ALTER TABLE `log_ot`
  ADD CONSTRAINT `fk_log_ot_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_log_ot_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pay_register`
--
ALTER TABLE `pay_register`
  ADD CONSTRAINT `fk_pay_register_hrm_employee_job_info1` FOREIGN KEY (`hrm_employee_job_info_id`) REFERENCES `hrm_employee_job_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pay_register_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pay_register_hrm_month1` FOREIGN KEY (`hrm_month_id`) REFERENCES `hrm_month` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pay_register_hrm_salary_generate_master1` FOREIGN KEY (`hrm_salary_generate_master_id`) REFERENCES `hrm_salary_generate_master` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pay_register_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pay_register_cw`
--
ALTER TABLE `pay_register_cw`
  ADD CONSTRAINT `fk_pay_register_cw_hrm_plant_with_section1` FOREIGN KEY (`hrm_plant_with_section_id`) REFERENCES `hrm_plant_with_section` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pay_register_cw_pay_register1` FOREIGN KEY (`pay_register_id`) REFERENCES `pay_register` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pay_register_details`
--
ALTER TABLE `pay_register_details`
  ADD CONSTRAINT `fk_pay_register_details_hrm_salary_head1` FOREIGN KEY (`hrm_salary_head_id`) REFERENCES `hrm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pay_register_details_pay_register1` FOREIGN KEY (`pay_register_id`) REFERENCES `pay_register` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `permission_module`
--
ALTER TABLE `permission_module`
  ADD CONSTRAINT `fk_permission_module_module_info1` FOREIGN KEY (`module_info_id`) REFERENCES `module_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_permission_module_permissions1` FOREIGN KEY (`permissions_id`) REFERENCES `permissions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `fk_permission_role_permissions1` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_permission_role_roles1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `fk_role_user_roles1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_role_user_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tmp_employee_shift`
--
ALTER TABLE `tmp_employee_shift`
  ADD CONSTRAINT `fk_tmp_employee_shift_hrm_employee1` FOREIGN KEY (`hrm_employee_id`) REFERENCES `hrm_employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tmp_employee_shift_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tmp_employee_shift_hrm_shift1` FOREIGN KEY (`hrm_shift_id`) REFERENCES `hrm_shift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user_location`
--
ALTER TABLE `user_location`
  ADD CONSTRAINT `fk_user_location_hrm_location1` FOREIGN KEY (`hrm_location_id`) REFERENCES `hrm_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_location_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
